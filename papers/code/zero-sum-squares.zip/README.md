There are 3 files in this folder:

- The file `claims.py` will check the small cases needed in the proofs of Claim 1 and Claim 2. If the program finds a case which it cannot solve, it will print this to `Stdout`.
- The file `small-cases.py` checks for non-diagonal zero-sum square free matrices with discrepancy at most n^2/4. The code prints a line for each n checked which gives the value of n, the value of m,  the maximum discrepancy allowed (which should be floor(n^2/4)) and whether it can find a solution.
- The file `extremal.py` checks for zero-sum square free matrices with discrepancy at most n^2/2 if n is even and at most (n-1)^2/4 - 1 if n is odd which are neither diagonal or the conjectured extremal example. The output syntax is the same as `small-cases.py`.

All files can be run using `python {{filename}}`. The files `small-cases.py` and `extremal.py` require [PySAT](https://github.com/pysathq/pysat). For information about installing PySAT see [https://github.com/pysathq/pysat#installation](https://github.com/pysathq/pysat#installation).