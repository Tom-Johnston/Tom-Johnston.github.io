import math

print("Checking bounds for claims 1 and 2 for 30 <= n < 600")

for n in range(30, 600):
    m = n//2 #m corresponds to n' in the paper. 
    t0 = math.ceil(0.5 * (math.sqrt(3*m*m + 1) - 1)) #A lower bound on t
    t1 = (2*n + 1)//3 #An exclusive upper bound on t. This may not be perfect as we have bounded floor(t/2) by (t-1)/2.

    #Check Claim 1
    if 2*t0 + t0//2 -2 < n - 1:
        print("Unable to verify Claim 1 for n = ", n)

    k = (5*n + 5)//6
    for t in range(t0, t1):

        s = min(k, t + t//2)
        r = k - s

        a1 = s*s - (t*(t+1))/2
        a4 = r
        a5 = r*(r-1)//2

        #Calculate a2 and a3 using a loop
        a2 = 0
        a3 = 0

        for i in range(1, r + 1):
            a2 += 2 *(t- i)
            a3 += 2*((t + 1 - i)//2) 

        #Calculate a lower bound on the discrepancy of n
        d = 2*(a1 + a2 + a3 + a4 + a5) - k*k + 11*(n-k)*(n-k)/4 - 10*(n-k)
        
        
        if d <= n*n/4:
            print("Unable to verify Claim 2 for n = ", n, " t = ", t)
            
print("Finished checking claims 1 and 2.")
