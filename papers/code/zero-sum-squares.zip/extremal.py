from pysat.solvers import Cadical
from pysat.card import *

#Each entry a_{i,j} is mapped to a variable x_{k} which represents if a_{i,j} is a 1 or a -1.

def canSAT(n, m , d):

	#Map an entry a_{i,j} to a variable x_{k}.
	def encode(i, j):
		return m*i + j + 1

	#Use the CaDiCaL solver
	g = Cadical()

	#Loop over every square and ensure it isn't a zero-sum square.
	for i in range(0, n):
		for j in range(0, m):
			#Bound the size of s for a square starting at (i,j).
			sUp = n - i
			if m - j < sUp:
				sUp = m - j
			for s in range(1, sUp):
				lits = [encode(i,j), encode(i+s,j), encode(i, j +s), encode(i+s, j+s)]
				g.add_clause([lits[0], lits[1], -lits[2], -lits[3]])
				g.add_clause([lits[0], -lits[1], lits[2], -lits[3]])
				g.add_clause([lits[0], -lits[1], -lits[2], lits[3]])
				g.add_clause([-lits[0], lits[1], lits[2], -lits[3]])
				g.add_clause([-lits[0], lits[1], -lits[2], lits[3]])
				g.add_clause([-lits[0], -lits[1], lits[2], lits[3]])

	#For each t, ban the t-diagonal matrix and its reflections.
	for t in range(0, n +m - 1):
		tmp1 = [0]*(n*m)
		tmp2 = [0]*(n*m)
		tmp3 = [0]*(n*m)
		tmp4 = [0]*(n*m)
		for i in range(0,n):
			for j in range(0,m):
				if i+j <= t+1:
					tmp1[encode(i, j)-1] = encode(i, j)
				else:
					tmp1[encode(i, j)-1] = -encode(i, j)


				if n-i+j <= t+1:
					tmp2[encode(i, j)-1] = encode(i, j)
				else:
					tmp2[encode(i, j)-1] = -encode(i, j)

				if i+n-j <= t+1:
					tmp3[encode(i, j)-1] = encode(i, j)
				else:
					tmp3[encode(i, j)-1] = -encode(i, j)
				if n-i+n-j <= t+1:
					tmp4[encode(i, j)-1] = encode(i, j)
				else:
					tmp4[encode(i, j)-1] = -encode(i, j)
		g.add_clause(tmp1)
		g.add_clause(tmp2)
		g.add_clause(tmp3)
		g.add_clause(tmp4)

        #Ban the conjectured extremal example and its reflections.
		tmp1 = [0]*(n*m)
		tmp2 = [0]*(n*m)
		tmp3 = [0]*(n*m)
		tmp4 = [0]*(n*m)

		for i in range (0, n):
			for j in range(0,n):
				if i % 2 == 0 and j % 2 == 0:
					tmp1[encode(i,j) - 1] = encode(i,j)
				else:
					tmp1[encode(i,j) - 1] = -encode(i,j)
				
				if (n - 1 -i) % 2 == 0 and j % 2 == 0:
					tmp2[encode(i,j) - 1] = encode(i,j)
				else:
					tmp2[encode(i,j) - 1] = -encode(i,j)
				
				if i % 2 == 0 and (n - j - 1) % 2 == 0:
					tmp3[encode(i,j) - 1] = encode(i,j)
				else:
					tmp3[encode(i,j) - 1] = -encode(i,j)
				
				if (n - i - 1) % 2 == 0 and (n - j - 1) % 2 == 0:
					tmp4[encode(i,j) - 1] = encode(i,j)
				else:
					tmp4[encode(i,j) - 1] = -encode(i,j)
				
		g.add_clause(tmp1)
		g.add_clause(tmp2)
		g.add_clause(tmp3)
		g.add_clause(tmp4)

	#Ensure the discrepancy is at most d.
	cnf = CardEnc.atmost(list(range(1, n*m+1)), (n*m + d)//2)
	#The cardinality clause introduces extra variables. Find the largest variable.
	top_id = 0
	for c in cnf.clauses:
		top_id = max(top_id, max(c))
	#Ensure the discrepancy is at least 0. 
	cnf2 = CardEnc.atleast(list(range(1, n*m+1)), (n*m)//2, top_id=top_id)
	g.append_formula(cnf)
	g.append_formula(cnf2)

	return g.solve()

if __name__ == "__main__":
	for n in range(1, 100):
		if n % 2 == 1:
			d = (n-1)*(n-1)//2 - 1
		else:
			d = (n*n)//2
		print("n: ", n, "disc: ", d, "canSAT: ", canSAT(n,n,d))