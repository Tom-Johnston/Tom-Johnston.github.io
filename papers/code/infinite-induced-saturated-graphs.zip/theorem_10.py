from sage.all import *
import itertools
import time

def check_all_subgraphs(G):
    """
    Loop over all subsets of k vertices from G and check if there is set S such that G[S] is 3-connected.
    Note that since G is assumed to be bipartite, any such S must have at least 6 vertices.
    """

    for k in range(6, 13):

        for S in itertools.combinations(G.vertices(), k):
            subgraph = G.subgraph(S)
            if subgraph.is_triconnected():
                return True, S
        
    return False,[]


if __name__ == "__main__":
    # When verbose is set to True the code will print out the subset of vertices for each graph.
    verbose = False

    start_time = time.time()
    num_success = 0
    num_failure = 0

    # Choose the size of A.
    for a in range(5, 10):
        b = 12 - a # size of B.

        # All possible sets of a - 2 neighbours.
        X = itertools.combinations(range(a), a - 2)

        # Now loop over all ways of picking b neighbourhoods. The order doesn't matter, so we will pick combinations with replacement.
        for N in itertools.combinations_with_replacement(X, b):
            # Start with an empty graph
            G = Graph(12)
            for i, neigh in enumerate(N):
                # neigh is the neighbours of the ith vertex in B, which is vertex a + i
                # Loop over the neighbours and add the edges
                for u in neigh:
                    G.add_edge((a + i, u))
        
            # Take the three core and check if it has at least 6 vertices and is 3-connected. 
            # This is an obvious candidate and much cheaper than checking all the possible subgraphs.
            _, three_core_vertices = G.cores(3)
            three_core = G.subgraph(three_core_vertices)

            if three_core.order() >= 6 and three_core.is_triconnected():
                num_success += 1
                if verbose:
                    print("SUCCESS --", G.graph6_string(), "3-core is 3-connected")
                continue
            
            # Check all the subgraphs with at least 6 vertices to check if any of them are 3-connected.
            ok, verts = check_all_subgraphs(G)

            if ok:
                num_success += 1
                if verbose:
                    print("SUCCESS --", G.graph6_string(), f"G[{verts}] is 3-connected")
                continue

            num_failure += 1
            print("FAILURE --", G.graph6_string())


    print("Successes:", num_success)
    print("Failures:", num_failure)
    print(f"Took {time.time()-start_time}s.\n")
