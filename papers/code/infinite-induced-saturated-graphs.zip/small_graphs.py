from sage.all import *
from sage.graphs.connectivity import vertex_connectivity
from sage.graphs.connectivity import connected_components
import itertools
import time

def close_to_permutation_graph(G):
    """
    Returns True if G is not a permutation graph but there is an edge e and a non-edge f such that both G-e and G+f are permutation graphs.
    """
    # Check that G is not a permutation graph
    if G.is_permutation():
        return False
    
    # Look for an edge e such that G-e is a permutation graph
    for e in G.edges(labels=False):
        G.delete_edge(e)
        is_perm = G.is_permutation()
        G.add_edge(e)
        if is_perm:
            break
    else:
        return False
    
    # Look for a non-edge f such that G+f is a permutation graph
    for f in G.complement().edges(labels=False):
        G.add_edge(f)
        is_perm = G.is_permutation()
        G.delete_edge(f)
        if is_perm:
            break
    else:
        return False

    return True

def has_true_twin(G, v):
    """
    Returns True if the vertex v has a true win, i.e. has a neighbour u such that u has the same neighbours as v, except for u and v. 
    """
    neighbors = sorted(G.neighbors(v, closed=True)) # This includes the vertex v so that both u and v are included in both closed neighbourhoods.
    for u in G.neighbor_iterator(v):
        u_neighbours = sorted(G.neighbors(u, closed=True))
        if u_neighbours == neighbors:
            return True
    return False

def has_false_twin(G, v):
    """
    Returns True if the vertex v has a false twin, i.e. a non-neighbour u such that u has the same neighbours as v. 
    """
    neighbors = G.neighbors(v, closed=False) # This does not include the vertex v so that neither of u and v are included in the open neighbourhoods.
    for u in G.complement().neighbor_iterator(v):
        u_neighbours = G.neighbors(u, closed=False)
        if u_neighbours == neighbors:
            return True
    return False

def is_vertex_cut(G, verts):
    """
    Returns True if the vertices in verts are a cut in G.
    """
    H = G.copy()
    H.delete_vertices(verts)
    return not H.is_connected()

def check_pair(G, i, j, edge_2_cuts, non_edge_2_cuts):
    """
    Check if the pair {i,j} is either an edge- or non-edge fixing operation with respect to the graph G which has the given edge-2-cuts and non-edge-2-cuts
    """
    # Check that they do not have twins of different types
    if has_true_twin(G, i) and has_false_twin(G, j):
        return False
    if has_false_twin(G, i) and has_true_twin(G, j):
        return False
    
    H = G.copy()
    H = H.subgraph(H.vertices()) # This changes the backend to a sparse graph which supports edge labels.

    # Set H to have a red edge between vertices i and j to distinguish the unordered pair, and set cuts to either the non_edge_2_cuts or edge_2_cuts as appropriate.
    cuts = []
    if H.has_edge(i,j):
        H.delete_edge(i,j)
        H.add_edge(i,j, label="red")
        cuts = non_edge_2_cuts
    else:
        H.add_edge(i,j, label="red")
        cuts = edge_2_cuts

    for c in cuts:
        # Get the connected components of H - {u,v}, where {u,v} is the 2-cut.
        H2 = G.copy()
        H2.delete_vertices(c)
        comp = connected_components(H2, sort=False) # sort is set to False to avoid the DeprecationWarning

        for cc in comp:
            F = G.subgraph(list(c) + cc)
            F.delete_edge(c)
            F.add_edge(c, label="red")
            for verts in itertools.combinations(H.vertices(), F.num_verts()):
                if F.is_isomorphic(H.subgraph(verts), edge_labels=True):
                    return False
            
    return True

def cut_criterion(G):
    """
    Returns True if G has a fixing operation as described in Section 6.3
    """
    num_verts = G.num_verts()

    G.relabel(range(0, num_verts))

    # Check that the graph is not complete
    if G.num_edges() == (num_verts*(num_verts-1))//2:
        return False
    
    # Check that the graph is 2-connected
    if vertex_connectivity(G) < 2:
        return False
    
    # Get the edge-2-cuts and the non-edge-2-cuts
    edge_2_cuts = []
    non_edge_2_cuts = []
    for pair in itertools.combinations(range(num_verts), 2):
        if not is_vertex_cut(G, pair):
            continue
        if G.has_edge(pair):
            edge_2_cuts.append(pair)
        else:
            non_edge_2_cuts.append(pair)

    # Check if we can find an edge gatekeeper.
    for e in G.edges(labels=False):
        if check_pair(G, e[0], e[1], edge_2_cuts, non_edge_2_cuts):
            break
    else:
        return False
    
    # Check if we can find a non-edge gatekeeper.
    for f in G.complement().edges(labels=False):
        if check_pair(G, f[0], f[1], edge_2_cuts, non_edge_2_cuts):
            break
    else:
        return False
    return True

def core_one_one(G):
    """
    Returns the graph formed by iteratively remove all dominating or isolated vertices until no such vertices remain.
    """
    # Take a copy of G to avoid modifying G.
    H = G.copy()

    while True:
        num_verts = H.num_verts()
        # Loop over the vertices and check if any of them are isolated or dominating.
        for v in H.vertices():
            if H.degree(v) == 0 or H.degree(v) == num_verts - 1:
                # Remove the isolated or dominating vertex.
                H.delete_vertex(v)
                # Break out of the for loop and do another iteration of the while loop.
                break
        else:
            # No isolated or dominating vertices were found so we can break out of the while loop.
            break

    return H

def core_two_edge(G):
    """
    Returns the graph formed by iteratively removing all vertices of degree less than 2 and all vertices of degree exactly two whose neighbours are adjacent.
    """
    # Take a copy of G to avoid modifying G.
    H = G.copy()

    while True:
        # Loop over the vertices and check if we should remove them.
        for v in H.vertices():
            if H.degree(v) < 2:
                # Remove the vertex and break out of the for loop.
                H.delete_vertex(v)
                break
            if H.degree(v) == 2:
                # Check if the two neighbours of v are adjacent.
                x, y = H.neighbors(v)[0], H.neighbors(v)[1]
                if H.has_edge(x,y):
                    H.delete_vertex(v)
                    break
        else:
            # No vertex was removed and we are done
            return H
        
def core_two_non_edge(G):
    """
    Returns the graph formed by iteratively removing all vertices of degree less than 2 and all vertices of degree exactly two whose neighbours are not adjacent.
    """
    # Take a copy of G to avoid modifying G.
    H = G.copy()

    while True:
        # Loop over the vertices and check if we should remove them.
        for v in H.vertices():
            if H.degree(v) < 2:
                # Remove the vertex and break out of the for loop.
                H.delete_vertex(v)
                break
            if H.degree(v) == 2:
                # Check if the two neighbours of v are adjacent.
                x, y = H.neighbors(v)[0], H.neighbors(v)[1]
                if not H.has_edge(x,y):
                    H.delete_vertex(v)
                    break
        else:
            # No vertex was removed and we are done
            return H

def check_graph(G):
    """
    Check if the graph G is handled, as described in Section 6.
    """

    # First we will create the various cores of the graph.
    _, two_core_vertices = G.cores(2)
    two_core = G.subgraph(two_core_vertices)

    _, three_core_vertices = G.cores(3)
    three_core = G.subgraph(three_core_vertices)

    one_one_core = core_one_one(G)
    two_edge_core = core_two_edge(G)
    two_non_edge_core = core_two_non_edge(G)

    # Now we begin the checks

    # Check if the graph is a forest with a unique vertex of maximum degree.
    deg_seq = G.degree_sequence()
    max_deg = max(deg_seq)
    if G.is_forest() and deg_seq.count(max_deg) == 1:
        return True, "graph is a forest with a unique vertex of max degree."
    
    # Check if the 2-core is a copy of K_{2,p} where p >= 3.
    if two_core.num_verts() >= 5 and two_core.is_isomorphic(graphs.CompleteMultipartiteGraph([2, two_core.num_verts()-2])):
        return True, f"2-core of the graph is a copy of K_{{2,{two_core.num_verts()-2}}}."

    # Check if the 2-core is a copy of K_{1,1,p} where p >= 2.
    if two_core.num_verts() >= 4 and two_core.is_isomorphic(graphs.CompleteMultipartiteGraph([1,1, two_core.num_verts()-2])):
        return True, f"2-core of the graph is a copy of K_{{1,1,{two_core.num_verts()-2}}}."
    
    # Check if the 3-core is a 3-connected graph which is not complete
    if three_core.num_edges() != (three_core.num_verts()*(three_core.num_verts()-1))//2 and vertex_connectivity(three_core) >= 3:
        return True, "3-core is three-connected and not complete."

    # Check if the (1,1)-core is a copy of the bull graph.
    if one_one_core.is_isomorphic(Graph("DD[")):
        return True, "(1,1)-core is a copy of the bull graph."
    
    # Check if the 1-core is a copy of P_4
    if one_one_core.is_isomorphic(Graph("CR")):
        return True, "(1,1)-core is a copy of P_4."

    # Check if the graph is close to a permutation graph.
    if close_to_permutation_graph(G):
        return True, "close to a permutation graph."
    
    # Check if any of the cores satisfy the technical conditions of Theorem ...
    if cut_criterion(two_core):
        return True, "2-core of the graph satisfies the cut-criterion."
    if cut_criterion(three_core):
        return True, "3-core of the graph satisfies the cut-criterion."
    if cut_criterion(two_edge_core):
        return True, "2-edge-core of the graph satisfies the cut-criterion."
    if cut_criterion(two_non_edge_core):
        return True, "2-non-edge-core of the graph satisfies the cut-criterion."
    
    return False, "Unhandled"

if __name__ == "__main__":
    # When verbose is set to True the code will print out the reason that each graph is handled.
    verbose = False

    for n in range(3, 12):
        start_time = time.time()
        num_handled = 0
        num_unhandled = 0
        num_skipped = 0

        print("Checking all graphs on",n,"vertices...")

        for G in graphs.nauty_geng(f"{n}"):
            if G.num_edges() == 0 or G.num_edges() == (G.num_verts()*(G.num_verts()-1))//2:
                # We will skip the empty graph and the complete graph.
                num_skipped += 1
                if verbose:
                    print("SKIPPED --", G.graph6_string())
                continue
            ok, reason = check_graph(G)
            if ok:
                num_handled += 1
                if verbose:
                    print("HANDLED --", G.graph6_string(), "Reason: The",  reason)
                continue
            if not ok:
                ok, reason = check_graph(G.complement())
            if ok:
                num_handled += 1
                if verbose:
                    print("HANDLED --", G.graph6_string(), "Reason: The complement of the",  reason)
            else:
                num_unhandled += 1
                print("UNHANDLED --", G.graph6_string())
        print("Handled:", num_handled)
        print("Unhandled:", num_unhandled)
        print("Skipped:", num_skipped)
        print(f"Took {time.time()-start_time}s.\n")
