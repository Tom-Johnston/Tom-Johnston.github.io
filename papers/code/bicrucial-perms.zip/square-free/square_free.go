package main

import (
	"flag"
	"fmt"
	"time"
)

func main() {
	numWorkersPtr := flag.Int("numWorkers", 1, "The number of concurrent goroutines to use to enumerate the permutations.")
	nPtr := flag.Int("n", 13, "The size of the permutations to search for.")

	flag.Parse()

	numWorkers := *numWorkersPtr
	n := *nPtr

	start := time.Now()
	if n <= 2 {
		count := 1
		if n == 2 {
			count = 2
		}
		fmt.Printf("Found %v square-free permutations of length %v in %v.\n", count, n, time.Since(start))
		return
	}

	var count int
	if n%2 == 0 {
		c := make(chan int)
		for i := 0; i < numWorkers; i++ {
			tmp := i
			go func(c chan int) {
				c <- countEven(n, tmp, numWorkers)
			}(c)
		}
		for i := 0; i < numWorkers; i++ {
			count += <-c
		}
		close(c)
	} else {
		c := make(chan int)
		for i := 0; i < numWorkers; i++ {
			tmp := i
			go func(c chan int) {
				c <- countOdd(n, tmp, numWorkers)
			}(c)
		}
		for i := 0; i < numWorkers; i++ {
			count += <-c
		}
		close(c)
	}
	fmt.Printf("Found %v square-free permutations of length %v in %v.\n", count, n, time.Since(start))

}

func countEven(n, b, m int) int {
	midCount := 0
	buf := make([]int, 3*n)
	//Should we allow the permutation?
	t := func(a []int) bool {
		if len(a) == 2 && a[0] < a[1] {
			return false
		}
		if len(a) == 3 && a[1] < a[2] {
			return false
		}
		if len(a) == n/2 {
			midCount++
			if midCount%m != b {
				return false
			}
			midCount = b
		}
		return !endsWithSquare(a, buf)
	}
	iter := PermutationsByExtension(n, t)
	count := 0
	for iter.Next() {
		count++
	}
	return 4 * count
}

func countOdd(n int, b, m int) int {
	buf := make([]int, 6*n)
	lostSymNum := n + 1
	midCount := 0
	t := func(a []int) bool {
		if len(a) == n/2 {
			midCount++
			if midCount%m != b {
				return false
			}
			midCount = b
		}
		return !endsWithSquare(a, buf) && isCanonicalOdd(a, n, buf, &lostSymNum)
	}
	iter := PermutationsByExtension(n, t)
	countNoSym := 0
	countSym := 0
	for iter.Next() {
		//Check for symmetry
		if lostSymNum == n+1 {
			countSym++
		} else {
			countNoSym++
		}
	}
	return 4*countNoSym + 2*countSym
}

//buf must be of length at least 5*n.
func isCanonicalOdd(a []int, n int, buf []int, lostSymNumPtr *int) bool {
	m := len(a)
	if m > *lostSymNumPtr {
		return true
	}

	*lostSymNumPtr = n + 1

	mid := n / 2     //This is really (n-1)/2 but this is just n / 2 in integer arithemetic as n is odd.
	l := m - mid - 1 //This is the number of points we have past the mid point.

	if l <= 0 {
		return true
	}

	if l == 1 {
		if a[mid-1] < a[mid+1] && a[mid-1] < a[mid] {
			if a[mid] > a[mid+1] {
				*lostSymNumPtr = m
			}
			return true
		}
		return false

	}

	patt1 := buf[:2*l+1]
	patt2 := buf[2*l+1 : 4*l+2]
	copy(patt1, a[mid-l:])
	flatten(patt1, buf[4*l+2:])

	//Check the reverse flip
	for i := range patt2 {
		patt2[i] = 2*l - patt1[2*l-i]
	}
	if c := intsCompare(patt1, patt2); c > 0 {
		return false
	} else if c == 0 {
		*lostSymNumPtr = n + 1
		return true
	}
	*lostSymNumPtr = m
	return true
}
