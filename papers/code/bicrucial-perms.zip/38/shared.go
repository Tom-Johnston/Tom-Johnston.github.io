package main

//endsWithSquare checks if the permutation contains a square which ends at the last entry of a.
//buf is storage space which may be used in the computation. buf must have capacity at least 3*len(a).
func endsWithSquare(a []int, buf []int) bool {
	n := len(a)

	//Check for squares of length 4.
	if n >= 4 {
		if a[n-2] < a[n-1] && a[n-4] < a[n-3] {
			return true
		}
		if a[n-2] > a[n-1] && a[n-4] > a[n-3] {
			return true
		}
	}

	//Now check for squares of larger lengths.
	//Since we know the permutation has no squares of length 4, the length of any square must be a multiple of 8.
	for i := 4; i <= n/2; i += 4 {
		patt1 := buf[:i]
		patt2 := buf[n : n+i]
		copy(patt1, a[n-i:n])
		copy(patt2, a[n-2*i:n-i])
		flatten(patt1, buf[2*n:])
		flatten(patt2, buf[2*n:])
		if intsEqual(patt1, patt2) {
			return true
		}
	}
	return false
}

//flatten replaces src by the unique permutation of {0, 1, ..., len(src) - 1} which is order-isomorphic to src.
//If src[i] is the jth smallest entry amongst all the elements in src, then src[i] is set to j.
//buf is storage space that may be used in the computation. buf must have capacity at least len(src).
func flatten(src, buf []int) {
	n := len(src)
	if n == 4 {
		flatten4(src, buf)
		return
	}
	if n == 8 {
		flatten8(src, buf)
		return
	}

	if n == 16 {
		flatten16(src, buf)
		return
	}
	buf = buf[:n]
	copy(buf, src)
	sortInts(buf)

	for i, v := range src {
		u := intsIndex(buf, v)
		src[i] = u
	}
}

//flatten4 uses a sorting network to quickly flatten src when src is of length 4.
func flatten4(src, buf []int) {
	buf = buf[:4]
	buf[0], buf[1], buf[2], buf[3] = 0, 1, 2, 3
	if src[0] > src[2] {
		src[0], src[2] = src[2], src[0]
		buf[0], buf[2] = buf[2], buf[0]
	}
	if src[1] > src[3] {
		src[1], src[3] = src[3], src[1]
		buf[1], buf[3] = buf[3], buf[1]
	}
	if src[0] > src[1] {
		src[0], src[1] = src[1], src[0]
		buf[0], buf[1] = buf[1], buf[0]
	}
	if src[2] > src[3] {
		src[2], src[3] = src[3], src[2]
		buf[2], buf[3] = buf[3], buf[2]
	}
	if src[1] > src[2] {
		src[1], src[2] = src[2], src[1]
		buf[1], buf[2] = buf[2], buf[1]
	}

	src[buf[0]], src[buf[1]], src[buf[2]], src[buf[3]] = 0, 1, 2, 3
}

//flatten8 uses a sorting network to quickly flatten src when src is of length 8.
func flatten8(src, buf []int) {
	buf = buf[:8]
	buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7] = 0, 1, 2, 3, 4, 5, 6, 7
	if src[0] > src[2] {
		src[0], src[2] = src[2], src[0]
		buf[0], buf[2] = buf[2], buf[0]
	}
	if src[1] > src[3] {
		src[1], src[3] = src[3], src[1]
		buf[1], buf[3] = buf[3], buf[1]
	}
	if src[4] > src[6] {
		src[4], src[6] = src[6], src[4]
		buf[4], buf[6] = buf[6], buf[4]
	}
	if src[5] > src[7] {
		src[5], src[7] = src[7], src[5]
		buf[5], buf[7] = buf[7], buf[5]
	}
	if src[0] > src[4] {
		src[0], src[4] = src[4], src[0]
		buf[0], buf[4] = buf[4], buf[0]
	}
	if src[1] > src[5] {
		src[1], src[5] = src[5], src[1]
		buf[1], buf[5] = buf[5], buf[1]
	}
	if src[2] > src[6] {
		src[2], src[6] = src[6], src[2]
		buf[2], buf[6] = buf[6], buf[2]
	}
	if src[3] > src[7] {
		src[3], src[7] = src[7], src[3]
		buf[3], buf[7] = buf[7], buf[3]
	}
	if src[0] > src[1] {
		src[0], src[1] = src[1], src[0]
		buf[0], buf[1] = buf[1], buf[0]
	}
	if src[2] > src[3] {
		src[2], src[3] = src[3], src[2]
		buf[2], buf[3] = buf[3], buf[2]
	}
	if src[4] > src[5] {
		src[4], src[5] = src[5], src[4]
		buf[4], buf[5] = buf[5], buf[4]
	}
	if src[6] > src[7] {
		src[6], src[7] = src[7], src[6]
		buf[6], buf[7] = buf[7], buf[6]
	}
	if src[2] > src[4] {
		src[2], src[4] = src[4], src[2]
		buf[2], buf[4] = buf[4], buf[2]
	}
	if src[3] > src[5] {
		src[3], src[5] = src[5], src[3]
		buf[3], buf[5] = buf[5], buf[3]
	}
	if src[1] > src[4] {
		src[1], src[4] = src[4], src[1]
		buf[1], buf[4] = buf[4], buf[1]
	}
	if src[3] > src[6] {
		src[3], src[6] = src[6], src[3]
		buf[3], buf[6] = buf[6], buf[3]
	}
	if src[1] > src[2] {
		src[1], src[2] = src[2], src[1]
		buf[1], buf[2] = buf[2], buf[1]
	}
	if src[3] > src[4] {
		src[3], src[4] = src[4], src[3]
		buf[3], buf[4] = buf[4], buf[3]
	}
	if src[5] > src[6] {
		src[5], src[6] = src[6], src[5]
		buf[5], buf[6] = buf[6], buf[5]
	}

	src[buf[0]], src[buf[1]], src[buf[2]], src[buf[3]], src[buf[4]], src[buf[5]], src[buf[6]], src[buf[7]] = 0, 1, 2, 3, 4, 5, 6, 7
}

//flatten16 uses a sorting network to quickly flatten src when src is of length 16.
func flatten16(src, buf []int) {
	buf = buf[:16]
	buf[0], buf[1], buf[2], buf[3], buf[4], buf[5], buf[6], buf[7], buf[8], buf[9], buf[10], buf[11], buf[12], buf[13], buf[14], buf[15] = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15

	comps := [60][2]int{{0, 13}, {1, 12}, {2, 15}, {3, 14}, {4, 8}, {5, 6}, {7, 11}, {9, 10}, {0, 5}, {1, 7}, {2, 9}, {3, 4}, {6, 13}, {8, 14}, {10, 15}, {11, 12}, {0, 1}, {2, 3}, {4, 5}, {6, 8}, {7, 9}, {10, 11}, {12, 13}, {14, 15}, {0, 2}, {1, 3}, {4, 10}, {5, 11}, {6, 7}, {8, 9}, {12, 14}, {13, 15}, {1, 2}, {3, 12}, {4, 6}, {5, 7}, {8, 10}, {9, 11}, {13, 14}, {1, 4}, {2, 6}, {5, 8}, {7, 10}, {9, 13}, {11, 14}, {2, 4}, {3, 6}, {9, 12}, {11, 13}, {3, 5}, {6, 8}, {7, 9}, {10, 12}, {3, 4}, {5, 6}, {7, 8}, {9, 10}, {11, 12}, {6, 7}, {8, 9}}

	for i := range comps {
		x, y := comps[i][0], comps[i][1]
		if src[x] > src[y] {
			src[x], src[y] = src[y], src[x]
			buf[x], buf[y] = buf[y], buf[x]
		}
	}

	src[buf[0]], src[buf[1]], src[buf[2]], src[buf[3]], src[buf[4]], src[buf[5]], src[buf[6]], src[buf[7]], src[buf[8]], src[buf[9]], src[buf[10]], src[buf[11]], src[buf[12]], src[buf[13]], src[buf[14]], src[buf[15]] = 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
}

//isBicrucial checks if a is a permutation of {0, 1, ..., lan(a) - 1}, if it square-free and if every left/right extension of a contains a square.
//buf is storage space that may be used in the calculation. buf must be of length at least 4*len(a)+1.
func isBicrucial(a, buf []int) bool {
	return isPermutation(a, buf) && isSquareFree(a, buf) && everyLeftExtensionHasSquare(a, buf) && everyRightExtensionHasSquare(a, buf)
}

//isPermutation checks if a is a permutation of {0, 1, ..., len(a) - 1}.
//buf must have length at least len(a).
func isPermutation(a, buf []int) bool {
	n := len(a)
	buf1 := buf[:n]
	copy(buf1, a)
	sortInts(buf1)

	for i := range buf1 {
		if buf1[i] != i {
			return false
		}
	}

	return true
}

//isSquareFree checks if a is square free.
//It doesn't assume that a is a valid permutation.
//buf must be of length at least 3*len(a).
func isSquareFree(a []int, buf []int) bool {
	for i := 4; i < len(a)+1; i++ {
		if endsWithSquare(a[:i], buf) {
			return false
		}
	}
	return true
}

//everyRightExtensionHasSquare checks if every right extension of the permutation a gives a square.
//The input must be a valid permutation.
//buf must be of length at least 4*len(a) + 1.
func everyRightExtensionHasSquare(a []int, buf []int) bool {
	n := len(a)
	b := buf[:n+1]
	//Copy the permutation into b but space out the entries so we can slot entries in between them.
	for i := range a {
		b[i] = 2 * a[i]
	}
	//Try appending an extra entry.
	for j := -1; j < 2*n+1; j += 2 {
		b[n] = j
		if !endsWithSquare(b, buf[n+1:]) {
			return false
		}
	}
	return true
}

//everyLeftExtensionHasSquare checks if every left extension of the permutation a gives a square.
//The input must be a valid permutation.
//buf must be of length at least 4*len(a) + 1
func everyLeftExtensionHasSquare(a []int, buf []int) bool {
	n := len(a)
	b := buf[:n+1]
	//Copy the permutation into b but space out the entries so we can slot entries in between them.
	//We also reverse the permutation so we are now extending to the right.
	for i := range a {
		b[n-1-i] = 2 * a[i]
	}
	//Try appending an extra entry.
	for j := -1; j < 2*n+1; j += 2 {
		b[n] = j
		if !endsWithSquare(b, buf[n+1:]) {
			return false
		}
	}
	return true
}

//lowLeftExtension returns a lower bound on the length of a permutation which begins with the pattern a and is such that every left extension contains a square. If a is already such a permutation, this returns -1.
//a must be a permutation of {0, ..., len(a) - 1}. buf is storage space that may be used in the computation and must be of length at least 4*len(a) + 1.
//The code first `expands' the permutation a by multiplying every value by 2. It then iterates over each possible left-extension and checks if the new permutation contains a square. If it doesn't, we check if it is possible for the pattern to contain S_1 and currently have an incomplete S_2. If this is the case, we raise the lower bound to 2*|S_1|. If this is not the case, we must have a lower bound of 2*n.
//If there are multiple left-extensions where a can only contain S_1, then each S_1 must be distinct and hence the square is of a different length. This improves the bound slightly.
func lowLeftExtension(a []int, buf []int) int {
	n := len(a)

	if n <= 2 {
		return 7
	}

	b := buf[:n+1]

	//Our code naturally checks for squares at the end of a permutation so we will secretly reverse the permutation here.
	for i := 0; i < n; i++ {
		b[n-i-1] = 2 * a[i]
	}

	lowerBound := -1
	numberWithNoS2 := 0

mainLoop:
	for j := -1; j < 2*n+1; j += 2 {
		b[n] = j
		//Check if this value of j is already covered.
		if endsWithSquare(b, buf[n+1:]) {
			continue
		}

		//Can this have a square which is already half in the permutation?
		//n is at least 3 so a square of length 4 is in the permutation and we only need to check for squares of length a multiple of 8.
		for i := 4; i <= n; i += 4 {
			//Let the extended permutation be (x, a'_0, ..., a'_{n-1}).
			//The potential square is (x, a'_0, ..., a'_{i-2}; a'_{i-1}, ..., a'_{n-1}, ...).
			if 2*i <= n+1 {
				//We are contained entirely in b and would have been found.
				continue
			}
			//The last i elements of b are the reverse of S_1 and the remaining  n + 1 - i are the start of the reverse of S_2
			t := n + 1 - i            //Number of elements in S_2
			patt1 := buf[n+1 : n+1+t] //Take t elements from the buffer to be the start of the reverse of S_1
			//patt1 = (b[i], ..., b[n]) = (a'_{n - i - 1}, ..., a'_0, x)
			for k := 0; k < t; k++ {
				patt1[k] = b[n-t+1+k]
			}

			patt2 := buf[n+1+t : n+1+t+t] //Take t elements from the buffer to be the start of the reverse of S_2
			//patt2 = (b[0], b[1], ..., b[t-1]) = (a'_{n -1}, ..., a'_{i-1})
			for k := 0; k < t; k++ {
				patt2[k] = b[k]
			}

			//Check if patt1 and patt2 are order-isomorphic.
			flatten(patt1, buf[n+1+t+t:])
			flatten(patt2, buf[n+1+t+t:])
			if intsEqual(patt1, patt2) {
				if lowerBound < 2*i {
					lowerBound = 2*i - 1
				}
				continue mainLoop
			}
		}
		// We don't have any of the S_2 here already.
		numberWithNoS2++
	}
	//Since the length of a square must be a multiple of 8 and all of them must be distinct, we can improve the lower bound.
	if numberWithNoS2 > 0 {
		lowerBound = 8*((n+4)/4) + 8*(numberWithNoS2-1) - 1
	}
	return lowerBound
}

//intsIndex returns the index i in [0, n) at which a[i] >= x.
//This is a translation of sort.Search to work on []int.
func intsIndex(a []int, x int) int {
	// Define f(-1) == false and f(n) == true.
	// Invariant: f(i-1) == false, f(j) == true.
	n := len(a)
	i, j := 0, n
	for i < j {
		h := int(uint(i+j) >> 1) // avoid overflow when computing h
		// i ≤ h < j
		if a[h] < x {
			i = h + 1 // preserves f(i-1) == false
		} else {
			j = h // preserves f(j) == true
		}
	}
	// i == j, f(i-1) == false, and f(j) (= f(i)) == true  =>  answer is i.
	return i
}

//intsEqual returns true if a and b are the same and false otherwise.
func intsEqual(a, b []int) bool {
	if a == nil && b == nil {
		return true
	}
	if a == nil || b == nil {
		return false
	}
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

//intsCompare returns 1 if a is greater than b in lexicographic order, 0 if they are equal and -1 if b is greater than a.
func intsCompare(a, b []int) int {
	for i := 0; ; i++ {
		if i >= len(a) && i >= len(b) {
			return 0
		}
		if i >= len(a) {
			return -1
		}
		if i >= len(b) {
			return 1
		}

		if a[i] > b[i] {
			return 1
		}
		if a[i] < b[i] {
			return -1
		}
	}
}

//PermutationExtensionIterator holds the state for an iterator which iterates over all permutations by extending the permutation to the right.
type PermutationExtensionIterator struct {
	n     int
	a     []int
	f     func([]int) bool
	first bool
}

//PermutationsByExtension iterates over all permutations of {0, 1, ..., n -1} which pass the test function f at every step. The iterator starts with the empty permutation. It then does a DFS where the children of the permutation P of with length l < n are the permutations of length l + 1 formed by appending a number x in {0, ..., l} and increasing by 1 every entry of P which is at least x. The function f is called at each node of the DFS and the iterator will prune the children of a node v is f(v) is false.
func PermutationsByExtension(n int, f func([]int) bool) *PermutationExtensionIterator {
	return &PermutationExtensionIterator{n: n, a: nil, f: f}
}

//Value returns the current permutation.
//You must not modify the returned valued.
func (iter *PermutationExtensionIterator) Value() []int {
	return iter.a
}

//Next attempts to move to the next valid permutation, returning true if one exists and false otherwise.
func (iter *PermutationExtensionIterator) Next() bool {
	//Initialise
	if iter.a == nil || iter.first {
		//The first call of Next()
		iter.first = false
		iter.a = make([]int, 0, iter.n)
		if iter.n == 0 {
			return true
		}
	} else {
		//Not the first call so the last thing we did was visit a permutation.
		goto x3
	}

	//Extend
x1:
	iter.a = append(iter.a, len(iter.a))
	//Test
x2:
	if iter.f(iter.a) {
		//Success
		if len(iter.a) == iter.n {
			return true
		}
		goto x1
	}

	//Test has failed so we need to increase the state.
x3:
	if len(iter.a) == 0 {
		return false
	}

	x := iter.a[len(iter.a)-1]
	if x == 0 {
		iter.a = iter.a[:len(iter.a)-1]
		for i := range iter.a {
			iter.a[i]--
		}
		goto x3
	}

	for i := range iter.a {
		if iter.a[i] == x-1 {
			iter.a[i]++
			break
		}
	}
	iter.a[len(iter.a)-1]--
	goto x2

}
