The code to exhaustively check if there are any bicrucial permutations of length 38 takes a long time to run (over a month of CPU time) and requires nearly 90GiB of RAM. The following is the output obtained from the last run.

````
Found 24763327 unique mids, each of length 26, from left-crucial permutations of length 33 in 46m57.669519387s.
Found a total of 0 unique ends in 61h53m1.380408378s.
The entire process took 62h39m59.050061131s.
````