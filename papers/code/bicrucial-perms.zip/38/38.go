package main

import (
	"bytes"
	"flag"
	"fmt"
	"sort"
	"time"
)

func main() {
	const n = 38 //Size of the permutation.

	const P = 33 //Size of the prefix to search for.
	const S = 31 //Size of the suffix.
	const K = n - S

	numWorkersPtr := flag.Int("numWorkers", 1, "The number of concurrent goroutines to use to enumerate the permutations.")

	flag.Parse()

	numWorkers := *numWorkersPtr

	start := time.Now()

	c := make(chan [][]byte)
	for i := 0; i < numWorkers; i++ {
		tmp := i
		go func(c chan [][]byte) {
			c <- enumerateEnds(P, K, tmp, numWorkers)
		}(c)
	}
	mids := [][]byte{}
	for i := 0; i < numWorkers; i++ {
		mids = append(mids, <-c...)
	}

	if len(mids) == 0 {
		fmt.Printf("Found %v unique mids, each of length %v, from left-crucial permutations of length %v in %v.\n", 0, P-K, P, time.Since(start))
		return
	}

	//Sort the mids slice.
	sort.Slice(mids, func(i, j int) bool {
		a := mids[i]
		b := mids[j]
		return bytes.Compare(a, b) == -1

	})

	//Loop through the mids slice and remove duplicate entries.
	count := 1
	for i := 1; i < len(mids); i++ {
		if !bytes.Equal(mids[i], mids[i-1]) {
			mids[count] = mids[i]
			count++
		}
	}
	mids = mids[:count]

	close(c)
	fmt.Printf("Found %v unique mids each of length %v from left-crucial permutations of length %v in %v.\n", count, P-K, P, time.Since(start))

	//Try to extend each of the ends.

	lookForExtensionsStart := time.Now()

	//Now we split into workers where each worker checks some of the ends.
	//Each worker will get perWorker entries of ends except the last one which may get slightly less.
	perWorker := (count + numWorkers - 1) / numWorkers
	//Each worker will report how many potential ends were found using the channel c2.
	c2 := make(chan int)
	//Split off the last worker and give it a potentially different number of ends.
	for i := 0; i < numWorkers-1; i++ {
		go extendWorker(i, S, mids[i*perWorker:(i+1)*perWorker], c2)
	}
	go extendWorker(numWorkers, S, mids[(numWorkers-1)*perWorker:], c2)

	count = 0
	for i := 0; i < numWorkers; i++ {
		count += <-c2
	}

	fmt.Printf("Found a total of %v unique ends in %v.\n", count, time.Since(lookForExtensionsStart))
	fmt.Printf("The entire process took %v.\n", time.Since(start))
}

//N is the size of the permutation to search for.
//K is the number of elements at the start to throw away.
func enumerateEnds(N, K, b, m int) [][]byte {
	midCount := 0
	buf := make([]int, 6*N)
	becameLeftCrucial := N + 1

	ends := make([][]byte, 0)
	//Should we allow the permutation?
	t := func(a []int) bool {
		if len(a) == 2 && a[0] > a[1] {
			return false
		}
		if len(a) == 3 && a[1] > a[2] {
			return false
		}
		if len(a) == N/2 {
			midCount++
			if midCount%m != b {
				return false
			}
			midCount = b
		}
		//Do we need to check if we can be left-crucial?
		if becameLeftCrucial < len(a) {
			//We already are left-crucial so no.
			return !endsWithSquare(a, buf)
		}
		//We are no longer the same on the first becameLeftCrucial entries.
		becameLeftCrucial = N + 1
		if c := lowLeftExtension(a, buf); c > N {
			return false
		} else if c == -1 {
			becameLeftCrucial = len(a)
		}
		return !endsWithSquare(a, buf)
	}
	iter := PermutationsByExtension(N, t)
	for iter.Next() {
		tmp := make([]int, N-K)
		copy(tmp, iter.Value()[K:])
		flatten(tmp, buf)

		tmpBytes := make([]byte, N-K)
		for i := range tmpBytes {
			tmpBytes[i] = byte(tmp[i])
		}
		ends = append(ends, tmpBytes)
	}

	if len(ends) == 0 {
		return ends
	}

	//Sort the ends slice.
	sort.Slice(ends, func(i, j int) bool {
		a := ends[i]
		b := ends[j]
		return bytes.Compare(a, b) == -1

	})

	//Loop through the ends slice and remove duplicate entries.
	count := 1
	for i := 1; i < len(ends); i++ {
		if !bytes.Equal(ends[i], ends[i-1]) {
			ends[count] = ends[i]
			count++
		}
	}
	ends = ends[:count]
	return ends
}

func extendWorker(id, n int, a [][]byte, c chan int) {

	// This is a little wasteful.
	flatInitialSegments := make([][]int, n)
	for i := range flatInitialSegments {
		flatInitialSegments[i] = make([]int, i)
	}

	buf := make([]int, 5*n)
	count := 0

	for index := range a {

		initialSegment := a[index]
		flatInitialSegments = flatInitialSegments[:len(initialSegment)+1]
		for i := 2; i < len(flatInitialSegments); i++ {
			for j := 0; j < i; j++ {
				flatInitialSegments[i][j] = int(initialSegment[j])
			}
			flatten(flatInitialSegments[i], buf)
		}

		t := func(a []int) bool {
			if len(a) >= 2 && len(a) <= len(initialSegment) {
				tmp := buf[:len(a)]
				copy(tmp, a)
				flatten(tmp, buf[len(a):])
				if !intsEqual(tmp, flatInitialSegments[len(a)]) {
					return false
				}
			}
			return endsWithSquare(a, buf) == false
		}

		iter := PermutationsByExtension(n, t)
		for iter.Next() {
			if everyRightExtensionHasSquare(iter.Value(), buf) {
				fmt.Printf("Found a  potential end: %v\n", iter.Value())
				count++
			}
		}
	}
	c <- count
}
