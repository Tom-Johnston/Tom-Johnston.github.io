package main

import "fmt"

func main() {
	buf := make([]int, 4*46+1)
	//perms contains the permutations we wish to check are square-free, left-crucial etc.
	perms := [][]int{
		//Proof of Theorem 5
		//Want right-crucial
		{3, 8, 5, 2, 4, 9, 1, 0, 7, 10, 6},
		//Want left-crucial
		{0, 6, 5, 2, 4, 7, 3, 1, 8, 14, 13, 9, 12, 15, 11, 10},
		//Want square-free
		{5, 4, 0, 3, 6, 2, 1, 10, 15, 12, 9, 11, 16, 8, 7, 14, 17, 13},

		//Proof of Theorem 6
		//Want left-crucial
		{8, 2, 0, 20, 29, 19, 3, 4, 7, 5, 1, 30, 31, 21, 6, 9, 22, 12, 10, 24, 26, 23, 13, 14, 17, 15, 11, 27, 28, 25, 16, 18},
		//Want right-crucial
		{1, 0, 4, 6, 3, 2, 5},
		//Want right-crucial
		{1, 0, 6, 8, 5, 3, 4, 7, 2},
		//Want right-crucial
		{0, 4, 7, 3, 1, 2, 8, 6, 5, 11, 13, 10, 9, 12},
		//Want right-crucial
		{0, 4, 7, 3, 1, 2, 8, 6, 5, 13, 15, 12, 10, 11, 14, 9},
		//Want right-crucial
		{0, 4, 7, 3, 1, 2, 8, 6, 5, 12, 13, 11, 9, 10, 16, 15, 14, 17},
		//Want right-crucial
		{0, 9, 12, 8, 1, 7, 13, 11, 10, 14, 15, 6, 3, 4, 17, 16, 5, 18, 19, 2},

		//Small even n
		//Want bicrucial and length 34
		{8, 2, 0, 21, 30, 20, 3, 4, 7, 5, 1, 31, 32, 22, 6, 9, 23, 12, 10, 25, 27, 24, 13, 14, 18, 15, 11, 28, 29, 26, 17, 19, 33, 16},
		//Want bicrucial and length 36
		{27, 33, 35, 22, 21, 26, 32, 31, 28, 30, 34, 19, 12, 20, 29, 25, 11, 18, 24, 9, 7, 10, 17, 16, 13, 15, 23, 4, 2, 5, 14, 8, 1, 3, 6, 0},
		//Want bicrucial and length 40
		{8, 2, 0, 20, 29, 19, 3, 4, 7, 5, 1, 30, 31, 21, 6, 9, 22, 12, 10, 24, 26, 23, 13, 14, 17, 15, 11, 27, 28, 25, 16, 18, 34, 33, 32, 37, 39, 36, 35, 38},
		//Want bicrucial and length 42
		{8, 2, 0, 20, 29, 19, 3, 4, 7, 5, 1, 30, 31, 21, 6, 9, 22, 12, 10, 24, 26, 23, 13, 14, 17, 15, 11, 27, 28, 25, 16, 18, 34, 33, 32, 39, 41, 38, 36, 37, 40, 35},
		//Want bicrucial and length 44
		{8, 2, 0, 20, 29, 19, 3, 4, 7, 5, 1, 30, 31, 21, 6, 9, 22, 12, 10, 24, 26, 23, 13, 14, 17, 15, 11, 27, 28, 25, 16, 18, 34, 33, 32, 38, 42, 37, 35, 36, 41, 40, 39, 43},
		//Want bicrucial and length 46
		{8, 2, 0, 25, 34, 24, 3, 4, 7, 5, 1, 35, 36, 26, 6, 9, 27, 12, 10, 29, 31, 28, 13, 14, 17, 15, 11, 32, 33, 30, 16, 23, 39, 38, 37, 40, 41, 22, 19, 20, 43, 42, 21, 44, 45, 18},
	}

	for _, a := range perms {
		fmt.Printf("Input:         %v\n", a)
		fmt.Printf("Length:        %v\n", len(a))
		fmt.Printf("Permutation:   %v\n", isPermutation(a, buf))
		fmt.Printf("Square-free:   %v\n", isSquareFree(a, buf))
		fmt.Printf("Left-crucial:  %v\n", isSquareFree(a, buf) && everyLeftExtensionHasSquare(a, buf))
		fmt.Printf("Right-crucial: %v\n", isSquareFree(a, buf) && everyRightExtensionHasSquare(a, buf))
		fmt.Printf("Bicrucial:     %v\n", isSquareFree(a, buf) && everyLeftExtensionHasSquare(a, buf) && everyRightExtensionHasSquare(a, buf))
		fmt.Println("")
	}
}
