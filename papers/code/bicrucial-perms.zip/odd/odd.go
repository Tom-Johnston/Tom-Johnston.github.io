package main

import (
	"fmt"
)

func main() {
	buf := make([]int, 1000) //Longer than necessary.
	for k := 3; k < 100; k += 4 {

		initialSegment := []int{0, 6, 5, 2, 4, 7, 3, 1, 8}
		cl1 := generatePi(k)

		m := 9 + 2*k + 1
		perm := make([]int, m)
		copy(perm, initialSegment)

		for i := 9; i < m; i++ {
			if (i-9)%4 == 0 {
				perm[i] = 50000 + (i-9)/4

			}
			if (i-9)%4 == 1 || (i-9)%4 == 3 {
				perm[i] = cl1[(i-9)/2] + 30000

			}
			if (i-9)%4 == 2 {
				perm[i] = 10000 + (i-9)/4
			}
		}
		perm = append(perm, 60000+3, 60000+8, 60000+5, 60000+2, 60000+4, 60000+9, 60000+1, 60000+0, 60000+7, 60000+10, 60000+6)
		flatten(perm, buf)
		fmt.Printf("Length: %v Bicrucial: %v Permutation: %v\n", len(perm), isBicrucial(perm, buf), perm)
	}

}

func generatePi(n int) []int {
	//Start with a square free permutation.
	buf := make([]int, n)
	curr := []int{0}
	for len(curr) < n {
		m := len(curr)
		next := make([]int, 2*m)

		for i := range next {
			//Top
			if i%4 == 0 {
				next[i] = m/2 + m + i/4
				continue
			}
			//Bottom
			if i%4 == 2 {
				next[i] = i / 4
				continue
			}
			//Middle
			next[i] = m/2 + curr[i/2]
		}
		curr = next
	}
	//Trim the square free permutation
	curr = curr[:n]
	//Flatten current
	flatten(curr, buf)
	return curr
}
