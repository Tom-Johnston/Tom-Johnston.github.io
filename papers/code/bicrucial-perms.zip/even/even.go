package main

import (
	"fmt"
)

func main() {
	buf := make([]int, 1000) //Slightly longer than necessary.
	for k := 1; k < 100; k += 4 {
		//The initial segment.
		initialSegment := []int{8, 2, 0, 20, 29, 19, 3, 4, 7, 5, 1, 30, 31, 21, 6, 9, 22, 12, 10, 24, 26, 23, 13, 14, 17, 15, 11, 27, 28, 25, 16, 18}
		l := len(initialSegment)
		//The square free permutation from Claim 1 we use to extend
		cl1 := generatePi(k)
		//Generate the permutation except for the last bit.
		//We will split the range into 7 regions which start at 0, 10000, 20000, ..., 60000 repesctively and we will then flattten the permutation at the end.
		m := l + 2*k - 1
		trunc := make([]int, m)
		copy(trunc, initialSegment)

		for i := l; i < m; i++ {
			if (i-l)%4 == 0 {
				trunc[i] = 50000 + (i-l)/4

			}
			if (i-l)%4 == 1 || (i-l)%4 == 3 {
				trunc[i] = cl1[(i-l-1)/2] + 30000

			}
			if (i-l)%4 == 2 {
				trunc[i] = 10000 + (i-l)/4
			}
		}

		var perm []int
		//Construction 1
		perm = make([]int, m)
		copy(perm, trunc)
		perm = append(perm, 40000+1, 40000, 60000+2, 60000+4, 60000+1, 60000+0, 60000+3)
		flatten(perm, buf)
		fmt.Printf("Length: %v Bicrucial: %v Permutation: %#v\n", len(perm), isBicrucial(perm, buf), perm)

		//Construction 2
		perm = make([]int, m)
		copy(perm, trunc)
		perm = append(perm, 40000+1, 40000, 60000+4, 60000+6, 60000+3, 60000+1, 60000+2, 60000+5, 60000+0)
		flatten(perm, buf)
		fmt.Printf("Length: %v Bicrucial: %v Permutation: %#v\n", len(perm), isBicrucial(perm, buf), perm)

		//Construction 3
		perm = make([]int, m)
		copy(perm, trunc)
		perm = append(perm, 40000+1, 40000, 60000+3, 60000+4, 60000+2, 60000+0, 60000+1, 60000+7, 60000+6, 60000+5, 60000+8)
		flatten(perm, buf)
		fmt.Printf("Length: %v Bicrucial: %v Permutation: %#v\n", len(perm), isBicrucial(perm, buf), perm)

		//Construction 4
		perm = make([]int, m)
		copy(perm, trunc)
		perm = append(perm, 40000+1, 40000, 60000+0, 60000+1, 20000+4, 20000+1, 20000+2, 60000+3, 60000+2, 20000+3, 60000+4, 60000+5, 20000+0)
		flatten(perm, buf)
		fmt.Printf("Length: %v Bicrucial: %v Permutation: %#v\n", len(perm), isBicrucial(perm, buf), perm)
	}
}

func generatePi(n int) []int {
	if n%4 != 1 {
		panic("n must be 1 mod 4")
	}
	//Start with a square free permutation.
	buf := make([]int, n)
	curr := []int{0}
	for len(curr) < n {
		m := len(curr)
		next := make([]int, 2*m)

		for i := range next {
			//Top
			if i%4 == 1 {
				next[i] = m/2 + m + i/4
				continue
			}
			//Bottom
			if i%4 == 3 {
				next[i] = i / 4
				continue
			}
			//Middle
			next[i] = m/2 + curr[i/2]
		}
		curr = next
	}
	//Trim the square free permutation
	curr = curr[:n]
	//Flatten current
	flatten(curr, buf)
	//Find the last entry
	x := curr[n-1]
	for i := range curr {
		if curr[i] > x {
			curr[i]--
		}
	}
	curr[n-1] = n - 1
	return curr
}
