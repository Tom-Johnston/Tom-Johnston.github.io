package main

import (
	"flag"
	"fmt"
	"time"
)

func main() {
	numWorkersPtr := flag.Int("numWorkers", 1, "The number of concurrent goroutines to use to enumerate the permutations.")
	nPtr := flag.Int("n", 11, "The size of the permutations to search for.")

	flag.Parse()

	numWorkers := *numWorkersPtr
	n := *nPtr

	start := time.Now()

	if n == 0 {
		fmt.Printf("Found %v left-crucial permutations of length %v in %v.\n", 0, n, time.Since(start))
		return
	}

	var count int
	c := make(chan int)
	for i := 0; i < numWorkers; i++ {
		tmp := i
		go func(c chan int) {
			c <- countLeftCrucial(n, tmp, numWorkers)
		}(c)
	}
	for i := 0; i < numWorkers; i++ {
		count += <-c
	}
	close(c)
	fmt.Printf("Found %v left-crucial permutations of length %v in %v.\n", count, n, time.Since(start))

}

func countLeftCrucial(n, b, m int) int {
	midCount := 0
	buf := make([]int, 6*n)
	becameLeftCrucial := n + 1
	//Should we allow the permutation?
	t := func(a []int) bool {
		if len(a) == 2 && a[0] < a[1] {
			return false
		}
		if len(a) == n/2 {
			midCount++
			if midCount%m != b {
				return false
			}
			midCount = b
		}
		//Do we need to check if we can be left-crucial?
		if becameLeftCrucial < len(a) {
			//We already are left-crucial so no.
			return !endsWithSquare(a, buf)
		}
		//We are no longer the same on the first becameLeftCrucial entries.
		becameLeftCrucial = n + 1
		if c := lowLeftExtension(a, buf); c > n {
			return false
		} else if c == -1 {
			becameLeftCrucial = len(a)
		}
		return !endsWithSquare(a, buf)
	}
	iter := PermutationsByExtension(n, t)
	count := 0
	for iter.Next() {
		count++
	}
	return 2 * count
}
