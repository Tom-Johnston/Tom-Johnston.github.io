# Bicrucial Permutations

This is the code to accompany the paper _The lengths for which bicrucial square-free permutations exist_.
The code is split into several folders with each folder containing the code for one particular task.

 - `38`: Exhaustively check that there are no square-free bicrucial permutations of length 38.
 - `bicrucial`: Count the number of bicrucial square-free permutations of a given length.
 - `even`: Generate bicrucial permutations of even lengths using the construction in Theorem 6.
 - `left-crucial`: Count the number of left-crucial square-free permutations of a given length.
 - `odd`: Generate bicrucial permutations of length 8k + 3 using the construction in Theorem 5.
 - `square-free`: Count the number of square-free permutations of a given length.

Each folder contains three `.go` files: `shared.go`, `ints_sort.go` and one file specific to the folder. The file `shared.go` contains functions which are shared between several of programs. It contains functions to ``flatten" a vector (replace it with the unique order-isomorphic permutation of {0, 1, ..., n-1}), to test if a permutation is square-free and many similar functions. It also contains an iterator to iterate over all permutations using a DFS where the children of a permutation are the right-extensions of the permutation. This takes a test function which determines if the DFS should allow the permutation. The searches are mostly done by changing this function. 

The programs to count permutations require the argument `n` to be passed (e.g. `-n 11`) where `n` is the length of the permutations to count. They also take the optional argument `numWorkers` which will split the work across `numWorkers` goroutines. In general, these will run in parallel if there is a sufficient number of cores. For example, the following command moves into the bicrucial directory (from this directory) and runs the program to enumerate all bicrucial permutations of length 19 using 4 goroutines.

````bash
cd bicrucial
go run bicrucial.go ints_sort.go shared.go -n 19 -numWorkers 4
# Sample output: Found 162190472 bicrucial permutations of length 19 in 7.9647576s.
````

The program `38` to exhaustively check there are no square-free bicrucial permutations of length 38 only takes the parameter `numWorkers` to split the work across several goroutines. The programs `odd` and `even` do not take any parameters.

