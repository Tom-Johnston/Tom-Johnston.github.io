# graphic-seq

This program computes the values of $G(n)$, the number of graphic sequences of length $n$, and outputs them to `stdout`. This sequence is OEIS sequences [A004251](https://oeis.org/A004251). The program also periodically outputs the current memory usage to `stderr`. A description of the recursion used by the program is given below. The program has two command line options.

- `numWorkers` specifies the number of different workers to use to compute each full layer.
- `maxFull` specifies the largest $n$ for which to calculate the $G(n)$ by computing all possible values of $f(n-1, \cdot, \cdot)$. A value of less than 1 is treated as infinity.

The program can run with the command `go run graphic-seq.go`, or compiled with `go build graphic-seq.go`.

## Recursion

As in the paper, we let $F(N, y, a)$ be the weighted number of walks with steps of size $-1$, $0$ or $+1$ which start at $y$, end in $\\{0,-1\\}$, take $N$ steps and satisfy $a + \sum_ {i=1}^k Y_ i \geq 0$ for all $0 \leq k \leq N$ and $a + \sum_ {i=1}^{N}Y_ i \equiv 0 \bmod 2$. Each walk is weighted by the number of steps of size $0$.

The function $F$ satisfies the recursion 
$$F(N, y, a) = F(N - 1, y + 1, a + y + 1) + F(N - 1, y - 1, a + y -1) + 2F(N-1, y, a + y)$$
with boundary condition $F(N, y, a) = 0$ whenever $a < 0$, and initial condition $F(0, y, a) = 1$ if $y \in \\{0, -1\\}$, $a \geq 0$ and $a$ even, and $F(0, y, a) = 0$ otherwise. As shown in the paper, $F$ has the following properties.
- $F(N, y, a) = 0$ if $y > N$ or $y < - N - 1$.
- If $y < 0$ and $a < y(y+1)/2$, then $F(N, y, a) = 0$.
- The area $a$ can decrease by at most $a' = \frac{N^2 - 2Ny + 2N - y^2 + \mathbb{1}_ {\text{odd}}(N-y)}{4}$. In particular, if $c(N, y) = c = \max\\{a', 0\\}$ and $a \geq c$, then $F(N, y, a) = F(N, y, c + \mathbb{1}_ {\text{odd}}(a-c))$.

Define the function $f$ by 
```math
f(N, y, a) = \begin{cases}
  F(N, y, a) - F(N, y, a - 1), & a \ne 0;\\
  F(N, y, 0), & a = 0.
 \end{cases}
 ```
From the properties of $F$ above, we can write down a recursion for $f$ as follows.

- Boundary condition: $f(N, y, a) = 0$ if $a < 0$.
- Initial condition: 
```math
f(0, y, a) = \begin{cases}
1, & y \in \{0,-1\}, a \text{ even}, a \geq 0;\\
-1, & y \in \{0,-1\}, a \text{ odd}, a \geq 0;\\
0, & \text{otherwise}.
\end{cases}
```

- If $a \neq 0$, then $$f(N, y, a) =  f(N - 1, y + 1, a + y + 1) + f(N - 1, y - 1, a + y -1) + 2f(N-1, y, a + y).$$
- If $a = 0$, then $$f(N, y, 0) =  \sum_ {i=0}^{y+1}f(N - 1, y + 1, i) + \sum_ {i=0}^{y-1}f(N - 1, y - 1, i) + 2 \sum_ {i=0}^{y} f(N-1, y, i)$$ where some of these sums may be empty.

We also get the following properties. 
- If $y > N$ or $y < -N -1$, then $f(N, y, a) = 0$.
- If $y < 0$ and $a < y(y+1)/2$, then $f(N, y, a) = 0$.
- Let $c(N, y)$ be as given above and suppose $a \geq c$. Then
$$f(N,y, a) = (-1)^{a + c + 1}f(N, y, c + 1).$$

Note that the last property also implies that if $x \geq c$, then $$\sum_ {i=0}^x f(N, y, i) =  \sum_ {i=0}^{c + \mathbb{1}_ {\text{odd}}(x + c)}f(N, y, i).$$

