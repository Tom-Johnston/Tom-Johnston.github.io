package main

import (
	"flag"
	"fmt"
	"math/big"
	"os"
	"runtime"
	"runtime/metrics"
	"strings"
	"sync"
)

const allMem = "/memory/classes/total:bytes"
const releasedHeap = "/memory/classes/heap/released:bytes"

func main() {

	sample := make([]metrics.Sample, 2)
	sample[0].Name = allMem
	sample[1].Name = releasedHeap

	numWorkersPtr := flag.Int("numWorkers", 1, "Specify the number of goroutines used to fill in each layer")
	maxFullPtr := flag.Int("maxFull", -1, "Specify the maximum n to calculate calculating the whole of each layer at a time (a value <1 is treated as infinity)")
	flag.Parse()

	numWorkers := *numWorkersPtr
	maxFull := *maxFullPtr

	fmt.Fprintf(os.Stderr, "Enumerating graphic sequences --- numWorkers: %v maxFull: %v\n", *numWorkersPtr, *maxFullPtr)

	//The actually enumeration starts at from n = 2, but we will output from 0 for completeness
	fmt.Println("0,1")
	fmt.Println("1,1")

	//Initialise
	N := 0

	//curr and prev will contain the whole layer for the current value of N and the previous value respectively.
	//The values f(N, y, a) are ordered by y and then by a.
	//f(0, -1, 0), f(0, -1, 1), f(0, 0, 0), f(0, 0, 1)
	curr := []*big.Int{big.NewInt(1), big.NewInt(-1), big.NewInt(1), big.NewInt(-1)}
	var prev []*big.Int

	//For each y, we will store the index of the first values of the form f(N, y, a).
	//This makes it much quicker to find the appropriate values.
	currStarts := []int{0, 2}
	var prevStart []int

	//Loop until we have calculated the value of n give by maxFull (or forever if maxFull < 1)
	for N != maxFull-1 {
		//Initialise the new layer
		N++
		prev = curr
		curr = make([]*big.Int, encode(N, N, cutoff(N, N))+2)

		prevStart = currStarts
		currStarts = make([]int, 2*(N+1))
		x := 0
		for i := 1; i < len(currStarts); i++ {
			x += cutoff(N, i-1-(N+1)) + 2
			if y := i - 1 - (N + 1); y < 0 {
				x -= (y * (y + 1)) / 2
			}
			currStarts[i] = x
		}

		//Compute the new layer
		var wg sync.WaitGroup
		wg.Add(int(numWorkers))
		for i := 0; i < numWorkers; i++ {
			tmp := i
			go computeSum(prev, curr, N, tmp, numWorkers, &wg, prevStart, currStarts)
		}
		wg.Wait()

		//Check the memory usage. We currently still have both curr and prev even though we no longer need prev
		metrics.Read(sample)
		if sample[0].Value.Kind() == metrics.KindBad || sample[1].Value.Kind() == metrics.KindBad {
			panic("problem reading metrics")
		}

		//Set prev to nil as it is no longer needed and should be collected by the call to the GC
		prev = nil
		runtime.GC()

		//Print the output
		fmt.Printf("%v,%v\n", N+1, curr[encode(N, 0, 0)])
		fmt.Fprintf(os.Stderr, "Total memory in use: %s\n", formatBytes(sample[0].Value.Uint64()-sample[1].Value.Uint64()))
	}

	//Now we keep trying to compute new values of G(n) by only calculating the values of f on demand.

	//Initialise new variables used in the calculation
	v := big.NewInt(0)
	r := big.NewInt(0)

	//cache will store the previously computed values. We use a separate map for each value of N
	cache := make([]map[int]*big.Int, 0)
	//At each step we will look at the top value from stack and try to calculate the value.
	//If it depends on values we don't already know, we add those to stack and go back to looking at the top value from stack.
	stack := make([][3]int, 0)

	//Store all the appropriate starts
	starts := make([][]int, 0)

	//We will try to calculate G(i + 1)
	i := N
	N0 := N
	for {
		//Initialise
		i++
		stack = append(stack, [3]int{i, 0, 0})
		cache = append(cache, make(map[int]*big.Int, 0))
		starts = append(starts, make([]int, 2*(i+1)))
		x := 0
		for j := 1; j < 2*(i+1); j++ {
			x += cutoff(i, j-1-(i+1)) + 2
			if y := j - 1 - (i + 1); y < 0 {
				x -= (y * (y + 1)) / 2
			}
			starts[i-N0-1][j] = x
		}

		//While the stack isn't empty, try to calculate the top value
		for len(stack) > 0 {
			params := stack[len(stack)-1]
			//We want to calculate f(N, y, a)
			N, y, a := params[0], params[1], params[2]
			v = v.Set(big.NewInt(0))

			//To calculate f(N, y, 0) = F(N, y, 0) we need F(N-1, y, y) = f(N-1, y, y) + f(N-1, y, y - 1) + ... + f(N-1, y, 0), so we split off this case.
			if a == 0 {
				//When N - 1 == n, we will be accessing values from curr
				if N-1 != N0 {
					//First check if all the values are known and if not, append them to the stack
					pass := true
					if y <= N-1 {
						t := y
						c := cutoff(N-1, y)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							if !known(N-1, y, i, N0, cache, starts[N-N0-2]) {
								stack = append(stack, [3]int{N - 1, y, i})
								pass = false
							}
						}
					}

					if y <= N && y >= 1 {
						t := y - 1
						c := cutoff(N-1, y-1)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							if !known(N-1, y-1, i, N0, cache, starts[N-N0-2]) {
								stack = append(stack, [3]int{N - 1, y - 1, i})
								pass = false
							}
						}
					}

					if y <= N-2 {
						t := y + 1
						c := cutoff(N-1, y+1)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							if !known(N-1, y+1, i, N0, cache, starts[N-N0-2]) {
								stack = append(stack, [3]int{N - 1, y + 1, i})
								pass = false
							}
						}
					}

					//Do we need to calculate more values?
					if !pass {
						continue
					}

					//Compute f(N, y, a)
					if y <= N-1 {
						t := y
						c := cutoff(N-1, y)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							recovCache(r, N-1, y, i, N0, cache, starts[N-N0-2])
							r.Lsh(r, 1)
							v.Add(v, r)
						}
					}

					if y <= N && y >= 1 {
						t := y - 1
						c := cutoff(N-1, y-1)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							v.Add(v, recovCache(r, N-1, y-1, i, N0, cache, starts[N-N0-2]))

						}
					}
					if y <= N-2 {
						t := y + 1
						c := cutoff(N-1, y+1)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							v.Add(v, recovCache(r, N-1, y+1, i, N0, cache, starts[N-N0-2]))
						}
					}
				} else {
					//Compute the values
					if y <= N-1 {
						t := y
						c := cutoff(N0, y)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							recov(r, curr, N0, y, i, currStarts)
							r.Lsh(r, 1)
							v.Add(v, r)
						}
					}

					if y <= N && y >= 1 {
						t := y - 1
						c := cutoff(N0, y-1)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							v.Add(v, recov(r, curr, N0, y-1, i, currStarts))
						}
					}

					if y <= N-2 {
						t := y + 1
						c := cutoff(N0, y+1)
						if t > c+1 {
							if t&1 == c&1 {
								t = c
							} else {
								t = c + 1
							}
						}
						for i := 0; i <= t; i++ {
							v.Add(v, recov(r, curr, N0, y+1, i, currStarts))
						}
					}
				}
			} else {
				//S != 0
				if N-1 == N0 {
					recov(r, curr, N0, y, a+y, currStarts)
					r.Lsh(r, 1)
					v.Add(v, r)
					v.Add(v, recov(r, curr, N0, y-1, a+y-1, currStarts))
					v.Add(v, recov(r, curr, N0, y+1, a+y+1, currStarts))
				} else {
					//Check if we know the values
					pass := true
					if !known(N-1, y, a+y, N0, cache, starts[N-N0-2]) {
						if c := cutoff(N-1, y); a+y > c+1 {
							stack = append(stack, [3]int{N - 1, y, c + 1})
						} else {
							stack = append(stack, [3]int{N - 1, y, a + y})
						}
						pass = false
					}
					if !known(N-1, y-1, a+y-1, N0, cache, starts[N-N0-2]) {
						if c := cutoff(N-1, y-1); a+y-1 > c+1 {
							stack = append(stack, [3]int{N - 1, y - 1, c + 1})
						} else {
							stack = append(stack, [3]int{N - 1, y - 1, a + y - 1})
						}
						pass = false
					}
					if !known(N-1, y+1, a+y+1, N0, cache, starts[N-N0-2]) {
						if c := cutoff(N-1, y+1); a+y+1 > c+1 {
							stack = append(stack, [3]int{N - 1, y + 1, c + 1})
						} else {
							stack = append(stack, [3]int{N - 1, y + 1, a + y + 1})
						}
						pass = false
					}
					if !pass {
						continue
					}
					//Compute the value
					recovCache(r, N-1, y, a+y, N0, cache, starts[N-N0-2])
					r.Lsh(r, 1)
					v.Add(v, r)
					v.Add(v, recovCache(r, N-1, y-1, a+y-1, N0, cache, starts[N-N0-2]))
					v.Add(v, recovCache(r, N-1, y+1, a+y+1, N0, cache, starts[N-N0-2]))
				}
			}
			//Create a deep copy of v on as few words as possible
			tmp := make([]big.Word, len(v.Bits()))
			copy(tmp, v.Bits())
			z := big.NewInt(0).SetBits(tmp)
			if v.Sign() == -1 {
				z.Neg(z)
			}

			//Add the value to the cache and pop the value from the stack
			x := encode(N, y, a)
			cache[N-N0-1][x] = z
			stack = stack[:len(stack)-1]
		}
		//The stack is empty so we have now calculated f(i, 0, 0)
		fmt.Printf("%v,%v\n", i+1, cache[i-N0-1][encode(i, 0, 0)])
		//Print the memory usage
		metrics.Read(sample)
		if sample[0].Value.Kind() == metrics.KindBad || sample[1].Value.Kind() == metrics.KindBad {
			panic("problem reading metrics")
		}
		fmt.Fprintf(os.Stderr, "Total memory in use: %s\n", formatBytes(sample[0].Value.Uint64()-sample[1].Value.Uint64()))
	}
}

// computeSum fills in all possible values of f(N, *, *) into curr using the values for f(N-1, *, *) given in prev.
// Only the values where f(N, y, a) where -(n+1) <= y <= n, 0 <= a <= a'(N, y) + 1 and (y >= 0  || a - (y*(y+1))/2 >= 0) need to calculated, and they are stored in order according first to y and then a. The function encode will give the index of where an entry in curr is.
// The function will only fill in the values f(N, y, *) where y = i mod j, which allows for some parallelism.
// The function will call wg.Done() when it has finished.
// prevStarts[i] should be the index in prev where the values f(N-1, i - N, *) start and similarly currStarts[i] should be the value in curr where the values f(N, i - (N + 1), *) will start.
func computeSum(prev, curr []*big.Int, N int, i, j int, wg *sync.WaitGroup, prevStarts, currStarts []int) {

	v := big.NewInt(0) //This will be used to calculate the values before they are copied to a new big.Int to be stored
	r := big.NewInt(0) //This will be used to retrieve values
	for y := -N - 1; y <= N; y++ {
		if (y%j) != i && (y%j) != -i {
			//Skip any values which are not i mod j. Note that % is negative when y is negative
			continue
		}

		for a := 0; a <= cutoff(N, y)+1; a++ {
			if y < 0 && a-(y*(y+1))/2 < 0 {
				//These values are known to be 0 and we don't need to calculate them or store them in curr
				continue
			}

			//We will use v to calculate
			v = v.Set(big.NewInt(0))
			//To calculate f(N, y, 0) = F(N, y, 0) we need values like F(N-1, y, y) = f(N-1, y, y) + f(N-1, y, y - 1) + ... + f(N-1, y, 0), so we split off this case.
			if a == 0 {
				if y <= N-1 {
					//If this isn't the case, then f(N - 1, y, y) is 0

					//Since f(N, y, a) alternates above c, we may not need to sum all the way up to y
					t := y
					c := cutoff(N-1, y)
					if t > c+1 {
						if t&1 == c&1 {
							t = c
						} else {
							t = c + 1
						}
					}
					for i := 0; i <= t; i++ {
						recov(r, prev, N-1, y, i, prevStarts)
						r.Lsh(r, 1)
						v.Add(v, r)
					}
				}

				if y <= N && y >= 1 {
					//If this isn't the case, then f(N - 1, y-1, y-1) is 0

					//Since f(N, y, a) alternates above c, we may not need to sum all the way up to y
					t := y - 1
					c := cutoff(N-1, y-1)
					if t > c+1 {
						if t&1 == c&1 {
							t = c
						} else {
							t = c + 1
						}
					}
					for i := 0; i <= t; i++ {
						v.Add(v, recov(r, prev, N-1, y-1, i, prevStarts))
					}
				}

				if y <= N-2 {
					//If this isn't the case, then f(N - 1, y+1, y+1) is 0

					//Since f(N, y, a) alternates above c, we may not need to sum all the way up to y
					t := y + 1
					c := cutoff(N-1, y+1)
					if t > c+1 {
						if t&1 == c&1 {
							t = c
						} else {
							t = c + 1
						}
					}
					for i := 0; i <= t; i++ {
						v.Add(v, recov(r, prev, N-1, y+1, i, prevStarts))
					}
				}
			} else {
				//a != 0
				recov(r, prev, N-1, y, a+y, prevStarts)
				r.Lsh(r, 1)
				v.Add(v, r)
				v.Add(v, recov(r, prev, N-1, y-1, a+y-1, prevStarts))
				v.Add(v, recov(r, prev, N-1, y+1, a+y+1, prevStarts))
			}

			//Make a deep copy of v using only the number of words required
			tmp := make([]big.Word, len(v.Bits()))
			copy(tmp, v.Bits())
			z := big.NewInt(0).SetBits(tmp)
			if v.Sign() == -1 {
				z.Neg(z)
			}
			//Store the deep copy in the appropriate place in the array
			index := currStarts[y+(N+1)]
			index += a
			if y < 0 {
				index -= (y * (y + 1)) / 2
			}
			curr[index] = z
		}
	}
	wg.Done()
}

// known checks if we have already calculated the value of f(N, P, S).
func known(N, y, a int, N0 int, cache []map[int]*big.Int, starts []int) bool {
	if a < 0 {
		//Value is known to be 0
		return true
	}

	if y > N {
		//Value is known to be 0
		return true
	}

	if y < -(N + 1) {
		//Value is known to be 0
		return true
	}

	if y < 0 && a-(y*(y+1))/2 < 0 {
		//Value is known to be 0
		return true
	}

	if c := cutoff(N, y); a > c {
		//The value is either f(N, y, c + 1) or -f(N, y, c + 1) (depending on the parity of a), so we only need to know f(N, y, c + 1)
		index := starts[y+(N+1)] + c + 1
		if y < 0 {
			index -= (y * (y + 1)) / 2
		}
		_, ok := cache[N-N0-1][index]
		return ok
	}

	index := starts[y+(N+1)] + a
	if y < 0 {
		index -= (y * (y + 1)) / 2
	}
	_, ok := cache[N-N0-1][index]
	return ok
}

// cutoff calculates the values c(N,y) given in the README.
func cutoff(N, y int) int {
	r := 0
	if (N-y)&1 == 1 {
		r = (N*N - 2*N*y + 2*N - y*y + 1) / 4
		if r < 0 {
			r = 0
		}
	} else {
		r = (N*N - 2*N*y + 2*N - y*y) / 4
		if r < 0 {
			r = 0
		}
	}
	return r
}

// encode gives the index of the stored entry f(N, y, a).
func encode(N, y, a int) int {
	r := 0
	for i := -N - 1; i < y; i++ {
		x := cutoff(N, i) + 2
		if i < 0 {
			x -= (i * (i + 1)) / 2
		}
		r += x
	}
	//Check cutoff for current value
	c := cutoff(N, y)
	if a > c {
		a = c + 1
	}
	if y < 0 {
		a -= (y * (y + 1)) / 2
	}
	r += a
	return r
}

// recov sets r to the value of f(N, y, a).
func recov(r *big.Int, arr []*big.Int, N, y, a int, starts []int) *big.Int {
	if a < 0 {
		return r.Set(big.NewInt(0))
	}

	if y > N {
		return r.Set(big.NewInt(0))
	}

	if y < -(N + 1) {
		return r.Set(big.NewInt(0))
	}

	if y < 0 && a-(y*(y+1))/2 < 0 {
		return r.Set(big.NewInt(0))
	}

	if c := cutoff(N, y); a > c {
		index := starts[y+(N+1)] + c + 1
		if y < 0 {
			index -= (y * (y + 1)) / 2
		}
		r.Set(arr[index])
		if a&1 == c&1 {
			r.Neg(r)
		}
		return r
	}
	index := starts[y+(N+1)]
	if y < 0 {
		a -= (y * (y + 1)) / 2
	}
	index += a
	r.Set(arr[index])
	return r
}

// recovCache sets r to the value of f(N, y, a).
// The value f(N, y, a) must either be known to be 0, or it must be in the cache. The function panics if it cannot return the value.
func recovCache(r *big.Int, N, y, a int, N0 int, cache []map[int]*big.Int, starts []int) *big.Int {
	if a < 0 {
		return r.Set(big.NewInt(0))
	}

	if y > N {
		return r.Set(big.NewInt(0))
	}

	if y < -(N + 1) {
		return r.Set(big.NewInt(0))
	}

	if y < 0 && a-(y*(y+1))/2 < 0 {
		return r.Set(big.NewInt(0))
	}

	if c := cutoff(N, y); a > c {
		//The value is either f(N, y, c+1) or -f(N, y, c + 1)
		index := starts[y+(N+1)] + c + 1
		if y < 0 {
			index -= (y * (y + 1)) / 2
		}
		v, ok := cache[N-N0-1][index]
		if !ok {
			panic(fmt.Sprintf("f(%v, %v, %v) is not in the cache or known to be 0\n", N, y, a))
		}
		r.Set(v)
		if a&1 == c&1 {
			r.Neg(r)
		}
		return r
	}

	index := starts[y+(N+1)] + a
	if y < 0 {
		index -= (y * (y + 1)) / 2
	}
	v, ok := cache[N-N0-1][index]
	if !ok {
		panic(fmt.Sprintf("f(%v, %v, %v) is not in the cache or known to be 0\n", N, y, a))
	}
	r.Set(v)
	return r
}

// F is a simple version of the recursion.
// This function is slow to calculate many values and works on int, but can be used to easily check small values.
func F(N, y, a int) int {
	if a < 0 {
		return 0
	}
	if y > N {
		return 0
	}
	if y < -N-1 {
		return 0
	}
	if N == 0 {
		if y != 0 && y != -1 {
			return 0
		}
		if a&1 != 0 {
			return 0
		}
		return 1
	}
	return 2*F(N-1, y, a+y) + F(N-1, y+1, a+y+1) + F(N-1, y-1, a+y-1)
}

// f is a simple implementation of the function f(N, y, a) using F(N, y, a).
// The function is slow to calculate many values and only works on int, but can be used to easily check small values.
func f(N, y, a int) int {
	if a <= 0 {
		return F(N, y, a)
	}
	return F(N, y, a) - F(N, y, a-1)
}

// formatBytes returns a human representation of a bytes
func formatBytes(a uint64) string {
	var s strings.Builder
	if (a >> 40) > 0 {
		s.WriteString(fmt.Sprintf("%vTiB ", (a >> 40)))
	}
	if (a>>30)&((1<<10)-1) > 0 {
		s.WriteString(fmt.Sprintf("%vGiB ", (a>>30)&((1<<10)-1)))
	}
	if (a>>20)&((1<<10)-1) > 0 {
		s.WriteString(fmt.Sprintf("%vMiB ", (a>>20)&((1<<10)-1)))
	}
	if (a>>10)&((1<<10)-1) > 0 {
		s.WriteString(fmt.Sprintf("%vKiB ", (a>>10)&((1<<10)-1)))
	}
	if a&((1<<10)-1) > 0 || s.Len() == 0 {
		s.WriteString(fmt.Sprintf("%vB ", a&((1<<10)-1)))
	}

	str := s.String()
	return str[:len(str)-1]
}
