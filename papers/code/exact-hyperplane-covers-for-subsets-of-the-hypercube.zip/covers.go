package main

import (
	"flag"
	"fmt"
	"math/rand"
)

//plane is a hyperplane of dimension n given by coefficients[0]*x[0] + ...  + coefficients[n-1]*x[n-1] = value. The points in {0,1}^n which are covered by the plane are those in covers.
type plane struct {
	coefficients []int
	value        int
	covers       []int
}

func main() {

	verbose := flag.Bool("verbose", false, "print information about successful sets of points.")
	flag.Parse()

	//By the argument in the proof of Theorem 5 we can assume that the four points are formed from
	//
	// 	0    0 0 0 0 0 0 0
	// 	u =  1 1 1 0 1 0 0
	// 	v    1 1 0 1 0 1 0
	// 	w    1 0 1 1 0 0 1
	//
	// by removing columns.

	mat := []int{0,
		0b1110100,
		0b1101010,
		0b1011001}

	//We only care about n >= 3
	for n := 3; n <= 7; n++ {
		//Choose which of the columns to keep.
		//It is possible to try to ban the same point twice when n = 3, but this won't cause any problems since we will find a plane containing exactly three of the points and will be looking for n -1 planes.
		iter := Combinations(7, n)
		for iter.Next() {
			//banned will be the set of points S which we must avoid
			banned := []int{}
			for _, x := range mat {
				y := 0
				for i, v := range iter.Value() {
					y |= ((x >> uint(v)) & 1) << uint(i)
				}
				banned = append(banned, y)
			}
			if !verifyClaim(n, banned, *verbose) {
				fmt.Println("Banned points:")
				for _, x := range banned {
					fmt.Printf("%0*b\n", n, x)
				}
				panic("Unable to verify claim for the above points.")
			}
		}
	}
	fmt.Println("Verified the claim.")
}

//removeBit removes the bit in position i, shifting the higher bits down.
func removeBit(x int, i int) int {
	//Create a mask for all bits before i.
	lowMask := (1 << uint(i)) - 1
	//Create the opposite mask for all bits in position i or later.
	hiMask := ^lowMask
	//Keep the low bits of x and the high bits of (x >> 1).
	return ((x >> 1) & hiMask) | (x & lowMask)
}

//dot returns the dot product of a point x in {0,1}^n with the vector c i.e. it returns c[0]*x[0] + c[1]*x[1] + ... + c[n-1]*x[n-1].
func dot(c []int, x int) (d int) {
	n := len(c)
	for j, v := range c {
		//Check if x[j] is 1 (else it is 0).
		if (x>>uint(n-1-j))&1 == 1 {
			d += v
		}
	}
	return
}

//verifyClaim verifies Theorem 5. A true return value indicates we have found a covering while a return value of false means we were unable to find a covering. A false return value does not mean that no such covering exists, only that we could not find it.
//The function generates all planes which have coefficients in {-1, 0, 1}. If any of these cover exactly 3 of the banned points, we only need to find an upper bound with n - 1 planes, otherwise we look for an upper bound with n - 2 planes. We try to find planes which cover all points except the banned points using the appropriate number of planes randomly. We try 2^30 random sets of planes before returning false.
//In the case n == 7, we restrict to planes which cover at least 40 points. The number 40 was chosen experimentally to return a solution quickly.
//If verbose is true, the code prints more information.
func verifyClaim(n int, banned []int, verbose bool) bool {

	if verbose {
		fmt.Println("Banned points:")
		for _, x := range banned {
			fmt.Printf("%0*b\n", n, x)
		}
	}

	target := n - 2

	//We will construct all planes with coefficients in coeffOptions.
	coeffOptions := []int{1, 0, -1}
	l := len(coeffOptions)

	//The number of options for each coefficient.
	productSizes := make([]int, n)
	for i := range productSizes {
		productSizes[i] = l
	}

	//Store all suitable planes.
	planes := make([]plane, 0)

	coefficients := make([]int, n)
	covers := make(SortedInts, 0)

	coeffIter := Product(productSizes...)

	for coeffIter.Next() {
		//Create the coefficients of the plane.
		for i, v := range coeffIter.Value() {
			coefficients[i] = coeffOptions[v]
		}

		//We still need to pick the value for the plane. Since we need to intersect at least 1 point, we can work out bounds on the value.
		maxValue := 0
		minValue := 0

		for _, v := range coefficients {
			if v > 0 {
				maxValue += v
			} else if v < 0 {
				minValue += v
			}
		}

	valueLoop:
		for value := minValue; value <= maxValue; value++ {
			//Check the plane doesn't cover any of the banned points.
			numBanned := 0
			for _, v := range banned {
				if dot(coefficients, v) == value {
					numBanned++
				}
			}

			if numBanned == 3 && target == n-2 {
				target = n - 1
				if verbose {
					fmt.Println("Plane hitting 3 found - Coefficients: ", coefficients, "Value: ", value)
				}
			}

			if numBanned > 0 {
				continue
			}

			//Find which points are covered.
			numCovered := 0
			covers = covers[:0]
			for k := 0; k < (1 << uint(n)); k++ {
				if dot(coefficients, k) == value {
					numCovered++
					covers = append(covers, k)
				}
			}

			//If a plane A covers a subset of another plane B, we are never going to need to use this plane A so we can remove it.

			//Start at the back of the array to make it easy to remove planes.
			//Note the order of the planes is potentially changed here.
			for i := len(planes) - 1; i >= 0; i-- {
				p := planes[i]
				//First check if the new plane is strictly better than an old plane, then check that the new plane isn't contained in the old plane.
				if c := IntersectionSize(p.covers, covers); c == len(p.covers) && len(covers) > c {
					//Better than the old plane so remove the old plane.
					planes[i] = planes[len(planes)-1]
					planes = planes[:len(planes)-1]
				} else if c == len(covers) {
					//Contained in old plane.
					continue valueLoop
				}
			}

			if n == 7 && len(covers) < 40 {
				continue
			}

			//Add the new plane to the list of planes.
			tmpCoefficients := make([]int, len(coefficients))
			copy(tmpCoefficients, coefficients)
			tmpCovers := make([]int, len(covers))
			copy(tmpCovers, covers)
			planes = append(planes, plane{coefficients: tmpCoefficients, value: value, covers: tmpCovers})
		}
	}
	//Shuffle the planes to destroy any structure.
	rand.Shuffle(len(planes), func(i, j int) { planes[i], planes[j] = planes[j], planes[i] })

	if verbose && target == n-2 {
		fmt.Println("Looking for n - 2 planes")
	}

	//Pick random sets of planes in the hope that most sets are easy.
	random := make([]int, target)
	for i := 0; i < 1<<uint(30); i++ {
		//Reset the covered elements
		covers = covers[:0]
		//Choose the random planes
		for j := 0; j < target; j++ {
			random[j] = rand.Intn(len(planes))
		}
		//Union the covered elements
		for _, v := range random {
			p := planes[v]
			covers.Add(p.covers...)
		}

		//Do we cover every point except the banned points?
		if len(covers) == (1<<uint(n))-len(banned) {
			if verbose {
				for _, v := range random {
					p := planes[v]
					fmt.Println("Coefficients: ", p.coefficients, "Value:", p.value, "Covers:", p.covers)
				}
				fmt.Println("")
			}
			return true
		}
	}
	return false
}
