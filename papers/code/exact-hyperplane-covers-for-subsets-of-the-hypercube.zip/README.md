The file `covers.go` will check the base case for Lemma 6. The code requires Go 1.13 or better and will require an internet connection to pull in a module the first time it is run. The code can be run from the terminal using `go run covers.go` and will (hopefully) state that it has verified the claim. If you want to see the details of the planes used to cover each point, you should pass the flag `-verbose`. 

The verbose output is also stored in `verbose.out`.

Note that although the code looks for solutions randomly, the same seed is always used for the PRNG and the program is actually deterministic.