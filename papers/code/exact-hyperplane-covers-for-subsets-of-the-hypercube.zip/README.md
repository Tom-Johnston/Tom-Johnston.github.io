The file `covers.go` contains the code that checks the base case for Lemma 6. It uses two iterators from the file `itertools.go` and a basic set storing ints in a slice in sorted order from the file `sorted_ints.go`. The code can be run from the terminal using `go run covers.go itertools.go sorted_ints.go` and will (hopefully) state that it has verified the claim. If you want to see the details of the planes used to cover each point, you should pass the flag `-verbose`. 

The verbose output is also stored in `verbose.out`.

Note that although the code looks for solutions randomly, the same seed is always used for the PRNG and the program is actually deterministic.