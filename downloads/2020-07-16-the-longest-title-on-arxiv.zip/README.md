To pull the metadata from arXiv, `cd` into the `data` folder and run the file `pull.go`. This will generate a series of files of the form `oai-\d*.xml` which contain the responses from arXiv.

To build the csv files and lists used for the blogpost, run the `stats.go` file. This assumes that the data files end are in the `data` folder (and this is relative) and that they end in `.xml` (to distinguish them from other files.)

```
$ cd data
$ go run pull.go
$ cd ..
$ go run stats.go
```

