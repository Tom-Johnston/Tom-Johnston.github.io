package main

import (
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"strconv"
	"time"
)

//ArxivRecord holds the information for the metadata of a single article.
//It is designed for parsing data in the arXiv format.
type ArxivRecord struct {
	DateStamp  string        `xml:"header>datestamp"`
	ID         string        `xml:"metadata>arXiv>id"`
	Created    string        `xml:"metadata>arXiv>created"`
	Updated    string        `xml:"metadata>arXiv>updated"`
	Title      string        `xml:"metadata>arXiv>title"`
	Authors    []ArxivAuthor `xml:"metadata>arXiv>authors>author"`
	Categories string        `xml:"metadata>arXiv>categories"`
	Abstract   string        `xml:"metadata>arXiv>abstract"`
}

//ArxivAuthor holds the information from arXiv on a single author.
//It is designed for parsing data in the arXiv format.
type ArxivAuthor struct {
	Forenames string `xml:"forenames"`
	KeyName   string `xml:"keyname"`
}

//ArxivResponse holds the information of a single response for ListRecords from arXiv.
//It is designed for parsing data in the arXiv format.
//Only the ResumptionToken field is necessary for pulling the data but the rest is necessary when parsing the data later and is left in here.
type ArxivResponse struct {
	ResponseDate    string        `xml:"responseDate"`
	Records         []ArxivRecord `xml:"ListRecords>record"`
	ResumptionToken string        `xml:"ListRecords>resumptionToken"`
}

func main() {
	//Initialise the resumption token
	resumptionToken := ""
	for true {
		//Construct the request.

		v := url.Values{}

		//The ListRecords verb always needs to be included.
		v.Add("verb", "ListRecords")

		//Either a resumptionToken must be specified or the parameters but not both.
		if resumptionToken != "" {
			v.Add("resumptionToken", resumptionToken)
		} else {
			//The structs are designed for parsing the arXiv format and won't work with other formats without modification.
			v.Add("metadataPrefix", "arXiv")

			//Only get articles which have been submitted to a maths categorie. I'm not sure what happens with the aliases like cs.IT.
			v.Add("set", "math")

			//Set this to pull in new recrods since a particular date. This is must be in ISO 8601 format and according to UTC.
			//You are most likely to copy this from the responseDate of your last request.
			//ArXiv refused the version with a time for some reason.
			// v.Add("from", "2020-06-19")
		}

		//Construct the request URL.
		req := "http://export.arxiv.org/oai2?" + v.Encode()

		//Make the request.
		resp, err := http.Get(req)
		if err != nil {
			panic(err)
		}

		//Check if we need to wait due to rate limiting.
		if resp.StatusCode == 503 {
			//Retry after
			fmt.Println("Retry-After")

			//Get the header value, parse into the number of seconds we need to wait and then sleep for that many seconds before trying again.
			t, err := strconv.Atoi(resp.Header.Get("Retry-After"))
			if err != nil {
				panic(err)
			}
			time.Sleep(time.Duration(t) * time.Second)
			continue
		}

		//Check if the request was successful.
		if resp.StatusCode != 200 {
			panic(fmt.Sprint("Unhandled status code", resp.StatusCode))
		}

		//Save the results to a file.
		name := fmt.Sprintf("oai-%v.xml", time.Now().Unix())
		file, err := os.Create(name)
		if err != nil {
			panic(err)
		}

		_, err = io.Copy(file, resp.Body)
		if err != nil {
			panic(err)
		}
		file.Close()
		resp.Body.Close()

		//We still need to get the resumption token so we will read the data back from the file, parse the data and extract the token.
		file, err = os.Open(name)
		if err != nil {
			panic(err)
		}
		reader := xml.NewDecoder(file)
		ar := new(ArxivResponse)
		reader.Decode(ar)
		resumptionToken = ar.ResumptionToken

		fmt.Println("Resumption Token: ", resumptionToken)

		if resumptionToken == "" {
			//We have finished getting the records.
			return
		}
	}
}
