package main

import (
	"encoding/csv"
	"encoding/xml"
	"fmt"
	"io"
	"io/ioutil"
	"os"
	"sort"
	"strings"
	"time"
)

//Information about categories

//RenamedCategories is map which converts old category identifiers to new ones. It also converts aliases such as cs.IT to their maths equivalent.
var RenamedCategories = map[string]string{"alg-geom": "math.AG", "dg-ga": "math.DG", "funct-an": "math.FA", "q-alg": "math.QA", "math-ph": "math.MP", "cs.IT": "math.IT"}

//MathCategories is a list of the maths categories. Note that this must be sorted.
var MathCategories = []string{"math.AC", "math.AG", "math.AP", "math.AT", "math.CA", "math.CO", "math.CT", "math.CV", "math.DG", "math.DS", "math.FA", "math.GM", "math.GN", "math.GT", "math.HO", "math.IT", "math.LO", "math.MG", "math.MP", "math.NA", "math.NT", "math.OA", "math.OC", "math.PR", "math.QA", "math.RA", "math.RT", "math.SG", "math.SP", "math.ST"}

//AppliedCategories is a subset of categories that we class as applied mathematics. Note that this must be sorted.
var AppliedCategories = []string{"math.CA", "math.DS", "math.MP", "math.NA", "math.OC", "math.ST"}

//PureCategories is a subset of categories that we consider to be pure mathematics. Note that this must be sorted.
var PureCategories = []string{"math.AC", "math.AG", "math.AT", "math.CT", "math.FA", "math.GN", "math.GR", "math.GT", "math.KT", "math.LO", "math.NT", "math.RA", "math.RT"}

//ArxivRecord holds the information for the metadata of a single article.
//It is designed for parsing data in the arXiv format.
type ArxivRecord struct {
	DateStamp  string        `xml:"header>datestamp"`
	ID         string        `xml:"metadata>arXiv>id"`
	Created    string        `xml:"metadata>arXiv>created"`
	Updated    string        `xml:"metadata>arXiv>updated"`
	Title      string        `xml:"metadata>arXiv>title"`
	Authors    []ArxivAuthor `xml:"metadata>arXiv>authors>author"`
	Categories string        `xml:"metadata>arXiv>categories"`
	Abstract   string        `xml:"metadata>arXiv>abstract"`
}

//ArxivAuthor holds the information from arXiv on a single author.
//It is designed for parsing data in the arXiv format.
type ArxivAuthor struct {
	Forenames string `xml:"forenames"`
	KeyName   string `xml:"keyname"`
}

//ArxivResponse holds the information of a single response for ListRecords from arXiv.
//It is designed for parsing data in the arXiv format.
//Only the ResumptionToken field is necessary for pulling the data but the rest is necessary when parsing the data later and is left in here.
type ArxivResponse struct {
	ResponseDate    string        `xml:"responseDate"`
	Records         []ArxivRecord `xml:"ListRecords>record"`
	ResumptionToken string        `xml:"ListRecords>resumptionToken"`
}

func main() {

	//Construct a map which returns the record given the arXiv ID.
	recordMap := make(map[string]ArxivRecord)

	//This code reads all files in the data directory and extracts the records in them.

	files, err := ioutil.ReadDir("data")
	if err != nil {
		panic(err)
	}

	for _, f := range files {
		if !strings.HasSuffix(f.Name(), ".xml") {
			continue
		}
		file, err := os.Open("data/" + f.Name())
		if err != nil {
			panic(err)
		}

		//Extract the records.
		reader := xml.NewDecoder(file)
		ar := new(ArxivResponse)
		reader.Decode(ar)

		for _, r := range ar.Records {
			//Remove any line breaks inserted by arXiv due to the maximum line length.
			r.Title = strings.ReplaceAll(r.Title, "\n  ", " ")

			//Check if the primary category is in maths.

			//Split the categories.
			categories := strings.Split(r.Categories, " ")
			//Extract the primary category.
			cat := categories[0]
			//Check for renaming.
			if renamedCat, ok := RenamedCategories[cat]; ok {
				cat = renamedCat
			}
			//Check if the categoryu is a maths category.
			index := sort.SearchStrings(MathCategories, cat)
			if index >= len(MathCategories) || MathCategories[index] != cat {
				continue
			}

			//Either add the record to the map of records or update the entry.
			if _, ok := recordMap[r.ID]; !ok {
				recordMap[r.ID] = r
			} else {
				//Parse the current date stamp
				currTime, err := time.Parse("2006-01-02", recordMap[r.ID].DateStamp)
				if err != nil {
					panic(err)
				}
				//Parse the new date stamp
				newTime, err := time.Parse("2006-01-02", r.DateStamp)
				if err != nil {
					panic(err)
				}

				//If the new version is later than the current version, update the record.
				if newTime.After(currTime) {
					recordMap[r.ID] = r
				}

			}
		}
	}

	//Write out the longest 1000 titles to long-titles.out
	longTitles, err := os.Create("long-titles.out")
	if err != nil {
		panic(err)
	}
	LongestTitles(recordMap, 100, longTitles)
	longTitles.Close()

	//Write out the shortest 100 titles to short-titles.out
	shortTitles, err := os.Create("short-titles.out")
	if err != nil {
		panic(err)
	}
	ShortestTitles(recordMap, 100, shortTitles)
	shortTitles.Close()

	//Write out the title distribution to titles.out
	titles, err := os.Create("titles.out")
	if err != nil {
		panic(err)
	}
	TitleLengths(recordMap, titles)
	titles.Close()

	//Write out the 100 papers with the most authors to most-authors.out
	mostAuthors, err := os.Create("most-authors.out")
	if err != nil {
		panic(err)
	}
	MostAuthors(recordMap, 100, mostAuthors)
	mostAuthors.Close()

	//Write out the distribution of the number of authors to authors.out
	authors, err := os.Create("authors.out")
	if err != nil {
		panic(err)
	}
	NumberOfAuthors(recordMap, authors)
	authors.Close()

	//Write out the authors with the most papers most-papers.out
	mostPapers, err := os.Create("most-papers.out")
	if err != nil {
		panic(err)
	}
	MostPapers(recordMap, "math", 100, mostPapers)
	mostPapers.Close()

	//Write out the authors with the most papers in combinatorics to most-papers-co.out
	mostPapersCo, err := os.Create("most-papers-co.out")
	if err != nil {
		panic(err)
	}
	MostPapers(recordMap, "math.CO", -1, mostPapersCo)
	mostPapersCo.Close()

	//Write out the distribution of the number of papers per author to papers.csv
	papers, err := os.Create("papers.out")
	if err != nil {
		panic(err)
	}
	NumberOfPapers(recordMap, papers)
	papers.Close()

}

//LongestTitles writes the num longest titles to w.
func LongestTitles(records map[string]ArxivRecord, num int, w io.Writer) {
	recordsSlice := make([]ArxivRecord, 0)
	for _, r := range records {
		recordsSlice = append(recordsSlice, r)
	}
	sort.Slice(recordsSlice, func(i, j int) bool { return len([]rune(recordsSlice[i].Title)) > len([]rune(recordsSlice[j].Title)) })
	for i := 0; i < num; i++ {
		r := recordsSlice[i]
		fmt.Fprintln(w, r.Categories, r.ID, r.Title)
	}
}

//ShortestTitles writes the num shortest titles to w.
func ShortestTitles(records map[string]ArxivRecord, num int, w io.Writer) {
	recordsSlice := make([]ArxivRecord, 0)
	for _, r := range records {
		recordsSlice = append(recordsSlice, r)
	}
	sort.Slice(recordsSlice, func(i, j int) bool { return len([]rune(recordsSlice[i].Title)) < len([]rune(recordsSlice[j].Title)) })
	for i := 0; i < num; i++ {
		r := recordsSlice[i]
		fmt.Fprintln(w, r.Categories, r.ID, r.Title)
	}
}

//TitleLengths writes the proportion of titles of each length by category to w in CSV format.
//math, pure and applied are also added as categories.
func TitleLengths(records map[string]ArxivRecord, w io.Writer) {
	//The number of titles of each length for a given category.
	titleLengths := make(map[string][]int)
	//The total number of titles with that category.
	freq := make(map[string]int)

	for _, r := range records {
		//Compute the title length
		titleLength := len([]rune(r.Title))

		//Find the primary category.
		categories := strings.Split(r.Categories, " ")
		categories = categories[:1]
		if renamedCat, ok := RenamedCategories[categories[0]]; ok {
			categories[0] = renamedCat
		}

		cat := categories[0]

		//Add it to the math category.
		categories = append(categories, "math")

		//Check if this is a pure category and, if so, add the pure category.
		index := sort.SearchStrings(PureCategories, cat)
		if index < len(PureCategories) && PureCategories[index] == cat {
			categories = append(categories, "pure")
		}

		//Check if this is an applied category and, if so, add the applied category.
		index = sort.SearchStrings(AppliedCategories, cat)
		if index < len(AppliedCategories) && AppliedCategories[index] == cat {
			categories = append(categories, "applied")
		}

		for _, cat := range categories {

			//Increase the total number in the category.
			freq[cat]++

			//Check if the slice of lengths has been initialised.
			if _, ok := titleLengths[cat]; !ok {
				//Initialise the slice of lengths.
				titleLengths[cat] = make([]int, titleLength+1)
				titleLengths[cat][titleLength]++
				continue
			}

			//Check if the slice is long enough to add this title.
			if titleLength >= len(titleLengths[cat]) {
				//Extend the slice
				tmp := make([]int, titleLength+1)
				copy(tmp, titleLengths[cat])
				tmp[titleLength]++
				titleLengths[cat] = tmp
			} else {
				titleLengths[cat][titleLength]++
			}
		}
	}

	//Make a csv writer.
	csvW := csv.NewWriter(w)
	//Construct the header row
	tmp := append([]string{"math", "pure", "applied"}, MathCategories...)
	csvW.Write(append([]string{"value"}, tmp...))

	//We will take the possible lengths from the math category as this has everything.
	for i := range titleLengths["math"] {
		//Value entry
		s := []string{fmt.Sprint(i)}

		for _, cat := range tmp {
			lens := titleLengths[cat]
			//If the array isn't long enough, the value is 0.
			if len(lens) <= i {
				s = append(s, "0")
				continue
			}
			s = append(s, fmt.Sprint(float64(lens[i])/float64(freq[cat])))
		}
		csvW.Write(s)
	}
	csvW.Flush()
}

//MostAuthors writes the num papers with the most authors to w
func MostAuthors(records map[string]ArxivRecord, num int, w io.Writer) {
	recordsSlice := make([]ArxivRecord, 0)
	for _, r := range records {
		recordsSlice = append(recordsSlice, r)
	}
	sort.Slice(recordsSlice, func(i, j int) bool { return len(recordsSlice[i].Authors) > len((recordsSlice[j].Authors)) })
	for i := 0; i < num; i++ {
		r := recordsSlice[i]
		fmt.Fprintln(w, r.Categories, r.ID, r.Title)
	}
}

//NumberOfAuthors writes the proportion of papers with each number of authors by category to w in CSV format.
//math, pure and applied are also added as categories.
func NumberOfAuthors(records map[string]ArxivRecord, w io.Writer) {
	//The number of papers with each NumberOfAuthors for a given category.
	numAuthors := make(map[string][]int)
	//The total number of titles with that category.
	freq := make(map[string]int)

	for _, r := range records {

		num := len(r.Authors)

		//Find the primary category.
		categories := strings.Split(r.Categories, " ")
		categories = categories[:1]
		if renamedCat, ok := RenamedCategories[categories[0]]; ok {
			categories[0] = renamedCat
		}

		cat := categories[0]

		//Add it to the math category.
		categories = append(categories, "math")

		//Check if this is a pure category and, if so, add the pure category.
		index := sort.SearchStrings(PureCategories, cat)
		if index < len(PureCategories) && PureCategories[index] == cat {
			categories = append(categories, "pure")
		}

		//Check if this is an applied category and, if so, add the applied category.
		index = sort.SearchStrings(AppliedCategories, cat)
		if index < len(AppliedCategories) && AppliedCategories[index] == cat {
			categories = append(categories, "applied")
		}

		for _, cat := range categories {

			//Increase the total number in the category.
			freq[cat]++

			//Check if the slice of lengths has been initialised.
			if _, ok := numAuthors[cat]; !ok {
				//Initialise the slice of lengths.
				numAuthors[cat] = make([]int, num+1)
				numAuthors[cat][num]++
				continue
			}

			//Check if the slice is long enough to add this value.
			if num >= len(numAuthors[cat]) {
				//Extend the slice
				tmp := make([]int, num+1)
				copy(tmp, numAuthors[cat])
				tmp[num]++
				numAuthors[cat] = tmp
			} else {
				numAuthors[cat][num]++
			}
		}
	}

	//Make a csv writer.
	csvW := csv.NewWriter(w)
	//Construct the header row
	tmp := append([]string{"math", "pure", "applied"}, MathCategories...)
	csvW.Write(append([]string{"value"}, tmp...))

	//We will take the possible lengths from the math category as this has everything.
	for i := range numAuthors["math"] {
		//Value entry
		s := []string{fmt.Sprint(i)}

		for _, cat := range tmp {
			lens := numAuthors[cat]
			//If the array isn't long enough, the value is 0.
			if len(lens) <= i {
				s = append(s, "0")
				continue
			}
			s = append(s, fmt.Sprint(float64(lens[i])/float64(freq[cat])))
		}
		csvW.Write(s)
	}
	csvW.Flush()
}

//MostPapers writes to w the num authors with the most papers in cat.
func MostPapers(records map[string]ArxivRecord, cat string, num int, w io.Writer) {
	//authors is a map from the author name to a map of number of papers by category. The categories also include math, pure and applied.
	authors := make(map[string]map[string]int)

	for _, r := range records {

		//Find the primary category.
		categories := strings.Split(r.Categories, " ")
		categories = categories[:1]
		if renamedCat, ok := RenamedCategories[categories[0]]; ok {
			categories[0] = renamedCat
		}

		c := categories[0]

		//Add it to the math category.
		categories = append(categories, "math")

		//Check if this is a pure category and, if so, add the pure category.
		index := sort.SearchStrings(PureCategories, c)
		if index < len(PureCategories) && PureCategories[index] == c {
			categories = append(categories, "pure")
		}

		//Check if this is an applied category and, if so, add the applied category.
		index = sort.SearchStrings(AppliedCategories, c)
		if index < len(AppliedCategories) && AppliedCategories[index] == c {
			categories = append(categories, "applied")
		}

		for _, a := range r.Authors {
			//Create the full name.
			key := a.Forenames + " " + a.KeyName

			//Check if the author already exists
			if _, ok := authors[key]; !ok {
				authors[key] = make(map[string]int)
			}

			//Add the paper to the authors counts for each category.
			for _, c := range categories {
				authors[key][c]++
			}
		}
	}

	authorsSlice := make([]map[string]int, 0)
	for name, a := range authors {
		a[name] = 0
		authorsSlice = append(authorsSlice, a)
	}

	sort.Slice(authorsSlice, func(i, j int) bool { return authorsSlice[i][cat] > authorsSlice[j][cat] })
	if num == -1 {
		num = len(authorsSlice)
	}
	for i := 0; i < num; i++ {
		a := authorsSlice[i]
		if authorsSlice[i][cat] == 0 {
			break
		}
		fmt.Fprintln(w, a)
	}

}

//NumberOfPapers a csv to w giving the number of authors with a given number of papers as a proportion of the number of authors with at least 1 paper.
func NumberOfPapers(records map[string]ArxivRecord, w io.Writer) {
	//authors is a map from the author name to a map of number of papers by category. The categories also include math, pure and applied.
	authors := make(map[string]map[string]int)

	for _, r := range records {

		//Find the primary category.
		categories := strings.Split(r.Categories, " ")
		categories = categories[:1]
		if renamedCat, ok := RenamedCategories[categories[0]]; ok {
			categories[0] = renamedCat
		}

		cat := categories[0]

		//Add it to the math category.
		categories = append(categories, "math")

		//Check if this is a pure category and, if so, add the pure category.
		index := sort.SearchStrings(PureCategories, cat)
		if index < len(PureCategories) && PureCategories[index] == cat {
			categories = append(categories, "pure")
		}

		//Check if this is an applied category and, if so, add the applied category.
		index = sort.SearchStrings(AppliedCategories, cat)
		if index < len(AppliedCategories) && AppliedCategories[index] == cat {
			categories = append(categories, "applied")
		}

		for _, a := range r.Authors {
			//Create the full name.
			key := a.Forenames + " " + a.KeyName

			//Check if the author already exists
			if _, ok := authors[key]; !ok {
				authors[key] = make(map[string]int)
			}

			//Add the paper to the authors counts for each category.
			for _, cat := range categories {
				authors[key][cat]++
			}
		}
	}

	countsByCat := make(map[string][]int)
	freq := make(map[string]int)

	for _, a := range authors {
		for cat, num := range a {
			if num == 0 {
				continue
			}

			//Let's only count them as an author of this category if it makes up at least half of their papers.
			// if 2*num/a["math"] < 1 {
			// 	continue
			// }

			freq[cat]++
			if len(countsByCat[cat]) <= num {
				tmp := make([]int, num+1)
				copy(tmp, countsByCat[cat])
				tmp[num]++
				countsByCat[cat] = tmp
			} else {
				countsByCat[cat][num]++
			}
		}
	}

	//Make a csv writer.
	csvW := csv.NewWriter(w)
	//Construct the header row
	tmp := append([]string{"math", "pure", "applied"}, MathCategories...)
	csvW.Write(append([]string{"value"}, tmp...))

	//We will take the possible lengths from the math category as this has everything.
	for i := range countsByCat["math"] {
		//Value entry
		s := []string{fmt.Sprint(i)}

		for _, cat := range tmp {
			lens := countsByCat[cat]
			//If the array isn't long enough, the value is 0.
			if len(lens) <= i {
				s = append(s, "0")
				continue
			}
			s = append(s, fmt.Sprint(float64(lens[i])/float64(freq[cat])))
		}
		csvW.Write(s)
	}
	csvW.Flush()
}
