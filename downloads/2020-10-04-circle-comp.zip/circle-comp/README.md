# Circle-comp

Circle-comp is designed to compare the different methods from [this blog post](https://tomjohnston.co.uk/blog/2020-10-04-enumerating-circle-graphs.html).

## Usage

An executable can be built with `go build comp.go`, or the code can be run directly with `go run comp.go`.

- The flag `-comp` can be specified to count the number of circle graphs using each method with a timeout of 1 hour for each `n` and each method.
- The flag `n` is required if `-comp` is not specified and will be the number of vertices in each graph.
- The flag `alg` specifies which method to use.